import { TestBed } from '@angular/core/testing';

import { CabbookingService } from './cabbooking.service';

describe('CabbookingService', () => {
  let service: CabbookingService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CabbookingService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
