import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Enquiry } from '../model/enquiry';

@Injectable({
  providedIn: 'root'
})
export class EnquiryService {

  constructor(private httpclient:HttpClient) { }

  url="http://localhost:8089/api/enquirys";

    addEnquiry(enquiry:Enquiry,userId:any,destinationId:any)
    {
     return this.httpclient.post(`${this.url}/${userId}/${destinationId}`,enquiry);
    }

    getAllEnquiry()
    {
      return this.httpclient.get(`${this.url}`);
    }
  
    deleteEnquiry(id:any)
    {
      return this.httpclient.delete(`${this.url}/${id}`);
    }

    getEnquiryById(userId:any)
    {
      return this.httpclient.get(`${this.url}/user/${userId}`);
    }
}
