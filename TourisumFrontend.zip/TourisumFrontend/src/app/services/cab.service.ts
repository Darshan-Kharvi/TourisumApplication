import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Cab } from '../model/cab';

@Injectable({
  providedIn: 'root'
})
export class CabService {

  constructor(private httpclient:HttpClient) { }

  url="http://localhost:8089/api/cab";

   addCab(cab:Cab)
     {
       return this.httpclient.post(`${this.url}`,cab);
     }
   
     getAllCabs()
     {
       return this.httpclient.get(`${this.url}`);
     }

     deleteCab(cabId:any){
      return this.httpclient.delete(`${this.url}/deleteCab/${cabId}`);
    }
  
    getCabById(cabId:any)
    {
      return this.httpclient.get(`${this.url}/getCabById/${cabId}`)
    }
  
    updateCab(cabId:any,updatedData: any)
    {
      return this.httpclient.put(`${this.url}/updateCab/${cabId}`,updatedData);
    }
}
