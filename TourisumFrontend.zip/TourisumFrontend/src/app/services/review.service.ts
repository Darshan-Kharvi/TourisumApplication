import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Review } from '../model/review';

@Injectable({
  providedIn: 'root'
})
export class ReviewService {

  constructor(private httpclient:HttpClient) { }

  url="http://localhost:8089/api/review";
  
    addReview(review:Review,userId:any)
    {
      return this.httpclient.post(`${this.url}/${userId}`,review);
    }
    
    getAllReview()
    {
      return this.httpclient.get(`${this.url}/reviews`);
    }
    
    deleteReview(id:any)
    {
      return this.httpclient.delete<Review>(`${this.url}/${id}`);
    }

    getReviewByUserId(userId:any)
    {
      return this.httpclient.get(`${this.url}/getReviewByUserUserId/${userId}`);
    }



}
