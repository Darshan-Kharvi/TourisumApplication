import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Cabbooking } from '../model/cabbooking';

@Injectable({
  providedIn: 'root'
})
export class CabbookingService {

  constructor(private httpclient:HttpClient) { }

  url="http://localhost:8089/api/cabbookings";

   addCabBooking(cabbooking:Cabbooking,userId:any,cabId:any)
    {
     return this.httpclient.post(`${this.url}/${userId}/${cabId}`,cabbooking);
    }

    getAllCabBookings()
  {
    return this.httpclient.get(`${this.url}`);
  }

  deleteCabBooking(id:any)
  {
    return this.httpclient.delete(`${this.url}/${id}`);
  }

  getCabBookingById(userId:any)
  {
    return this.httpclient.get(`${this.url}/user/${userId}`);
  }

  updateCabBookingStatusByCabBookingId(cabbookingId:any,cab:any)
  {
    return this.httpclient.put(`${this.url}/cabstatusupdate/${cabbookingId}`,cab);
  }


  cancelCabBooking(bookingId:any,cab:any)
  {
    return this.httpclient.put(`${this.url}/cancel/${bookingId}`,cab);
  }

}
