import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Package } from '../model/package';

@Injectable({
  providedIn: 'root'
})
export class PackageserviceService {

  constructor(private httpclient:HttpClient) { }

  url="http://localhost:8089/api/pacakge";
 
   addPackage(packages:Package)
   {
     return this.httpclient.post(`${this.url}`,packages);
   }
 
   getAllPackage()
   {
     return this.httpclient.get(`${this.url}`);
   }
 
   deletePackage(packageId:any){
     return this.httpclient.delete(`${this.url}/deletePackage/${packageId}`);
   }
 
   getPacakgeById(packageId:any)
   {
     return this.httpclient.get(`${this.url}/getPackageById/${packageId}`)
   }
 
   updatePackage(packageId:any,updatedData: any)
   {
     return this.httpclient.put(`${this.url}/updatePackage/${packageId}`,updatedData);
   }
  
}
