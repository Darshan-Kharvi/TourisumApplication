import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class paymentService {

  constructor(private httpclient:HttpClient) { }

  url="http://localhost:8089/api/payments"
  url1="http://localhost:8089/api/bankserver/validation"

   addpayment(payment:any,userId:any,bookingId:any,roomId:any,roomPrice:any)
    {
      console.log("inside the service");
      console.log(payment);
     return this.httpclient.post(`${this.url}/${userId}/${bookingId}/${roomId}/${roomPrice}`,payment);
    
    }

    getPaymentById(userId:any)
    {
      return this.httpclient.get(`${this.url}/user/${userId}`);
    }

    getAllPayments()
    {
      return this.httpclient.get(`${this.url}`);
    }

    getAllRoomPayments()
    {
      return this.httpclient.get(`${this.url}/getallpaymentsbyroom`);
    }

    getAllPackagePayments()
    {
      return this.httpclient.get(`${this.url}/getallpaymentsbypackage`);
    }

    getBankServer(bankserver:any)
    {
      return this.httpclient.post(`${this.url1}`,bankserver);
    }


}
