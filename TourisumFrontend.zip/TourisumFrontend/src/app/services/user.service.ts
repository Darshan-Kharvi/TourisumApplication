import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { User } from '../model/user';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private httpclient:HttpClient) { }

  url = "http://localhost:8089/api/users";

  registerUser(user:any)
  {
    return this.httpclient.post(`${this.url}`,user);
  }

 loginUser(user:any){
  console.log(user.accountEmail);
  console.log(user.password);
  return this.httpclient.get(`${this.url}/${user.accountEmail}/${user.password}`)
 }

 forgotpass(mail:string)
 {
  return this.httpclient.get(`${this.url}/findUserByEmail/${mail}`)
  } 
  updatenewpassbymail(mail:string,npassword:string,user:any){
  return this.httpclient.put(`${this.url}/findbymail/${mail}/${npassword}`,user);
  }

  adminLogin(mail:any,password:any){
    if(mail=="admin@gmail.com" && password=="admin@123"){
      return true;
    }else{
      return false;
    }
}

getAllUser()
{
  return this.httpclient.get(`${this.url}`);
}

deleteuser(id:any)
{
  return this.httpclient.delete(`${this.url}/deleteUser/${id}`);
}

getUserById(userid:any)
{
  return this.httpclient.get(`${this.url}/getUserById/${userid}`);
}
isUserLogin(userId:any)
{
  sessionStorage.setItem('userId',userId);
  return true;
}
userLogout()
{
sessionStorage.removeItem('userId');
}

updateUser(userId:any,updatedData: any)
{
  return this.httpclient.put(`${this.url}/${userId}`,updatedData);
}

getLoggedInUser(): Observable<User> 
{
  return this.httpclient.get<User>(`${this.url}/me`, { withCredentials: true });
}

checkbyemail(mail:string)
{
  console.log(mail);
  return this.httpclient.get(`${this.url}/findbyemail/${mail}`)
}

}
