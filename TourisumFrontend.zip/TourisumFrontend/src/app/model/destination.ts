export class Destination{
    destinationId:number|null;
    destinationName:string;
    destinationLocation:string;
    description:string;
    image:string;

    constructor(){
    this.destinationId=null;
    this.destinationName="";
    this.destinationLocation="";
    this.description="";
    this.image="";

    }
}