export class RoomBooking{
    bookingId:number|null;
    checkinDate: Date;
    checkoutDate:Date;
    totalMembers: number;
    childrens: number;
    status: string;
    price: number;
    roomType:string;
    rooms:string;

    constructor(){
        this.bookingId=null;
        this.checkinDate=new Date();
        this.checkoutDate=new Date();
        this.totalMembers=0;
        this.childrens=0;
        this.status="YET TO BOOK";
        this.price=0;
        this.roomType=" ";
        this.rooms=" ";

    }

}