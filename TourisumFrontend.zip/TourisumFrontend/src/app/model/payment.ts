export class Payment{

    paymentId:number|null;
    paymentDate:Date;
    paymentAmount:number;
    paymentStatus: string ; 
    cardholderName: string;
    cardNumber: string;
    exipireDate: string;
    cvv: string;

    constructor()
    {
        this.paymentId=null;
        this.paymentDate=new Date();
        this.paymentAmount=0;
        this.paymentStatus="DONE";
        this.cardholderName=" ";
        this.cardNumber=" ";
        this.exipireDate=" ";
        this.cvv=" ";


    }

}