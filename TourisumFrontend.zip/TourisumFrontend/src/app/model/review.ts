export class Review{
    reviewId:number|null;
    rating:number;
    comments:string;
    reviewDate:Date;
    reviewFor:string;

    constructor(){
    this.reviewId=null;
    this.rating=0;
    this.comments="";
    this.reviewDate=new Date();
    this.reviewFor="";
    }
}