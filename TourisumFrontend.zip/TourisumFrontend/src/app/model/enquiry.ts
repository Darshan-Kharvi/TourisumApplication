export class Enquiry{
    enquiryId:number|null;
    comments:string;
    enquiryDate:Date;
    enquiryFor:string;
    name:string;
    location:string;

    constructor(){
    this.enquiryId=null;
    this.comments="";
    this.enquiryDate=new Date();
    this.enquiryFor="";
    this.name="";
    this.location="";
    }
}