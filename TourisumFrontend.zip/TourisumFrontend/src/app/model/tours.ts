export class Tours{
    tourId:number|null;
    tourName:string;
    tourDescription:string;
    location:string;
    startDate:string;
    image:string;
    endDate:string;
    price:string;
    availableSeats:string;
    

    constructor(){
    this.tourId=null;
    this.tourName="";
    this.tourDescription="";
    this.location="";
    this.startDate="";
    this.image="";
    this.endDate="";
    this.price="";
    this.availableSeats="";
    }
}
