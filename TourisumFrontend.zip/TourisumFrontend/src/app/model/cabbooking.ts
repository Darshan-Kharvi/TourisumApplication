export class Cabbooking{
    bookingId:number|null;
    bookingDate:Date;
    totalMembers:number;
    childrens:number;
    status:string;
    price:string;
    cabType:string;
    picuplocation:string;
    droplocation:string;
    totaldays:string;
    totaldistance:string;

    constructor(){
        this.bookingId=null;
        this.bookingDate=new Date();
        this.totalMembers=0;
        this.childrens=0;
        this.status="BOOKED";
        this.price="";
        this.cabType="";
        this.picuplocation="";
        this.droplocation="";
        this.totaldays="";
        this.totaldistance="";
    }
}