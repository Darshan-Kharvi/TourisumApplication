export class Cab{
    cabId:number|null;
    cabName:string;
    image:string;
    price:number;
    cabtype:string;
    driverName:string;
    driverNo:string;
    totalSeats:string;
    vehicleNo:string;

    constructor(){
        this.cabId=null;
        this.cabName="";
        this.image="";
        this.price=0;
        this.cabtype="";
        this.driverName="";
        this.driverNo="";
        this.totalSeats="";
        this.vehicleNo="";
    }
}