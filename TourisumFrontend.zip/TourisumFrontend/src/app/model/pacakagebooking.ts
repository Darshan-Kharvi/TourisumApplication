export class PackageBooking{
    bookingId:number|null;
    bookingDate: Date;
    totalMembers: string;
    childrens: string;
    picupLocation: string;
    status: string;
    price: number;


constructor(){
this.bookingId=null;
this.bookingDate=new Date();

this.totalMembers=" ";
this.childrens=" ";
this.picupLocation=" ";
this.status="YET TO BOOK";
this.price=0;

}
}