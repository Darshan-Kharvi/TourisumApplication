export class Package{
    packageId:number|null;
    packageName:string;
    packageDescription:string;
    packagetype:string;
    image:string;
    packageprice:number;
    duration:string;
    cab:string;
    breakfast:string;
    sightvisit:string;
    room:string;
    campfire:string;
    meal:string;
    availableSeats:string;

    constructor(){
        this.packageId = null;
        this.packageName = "";
        this.packageDescription ="";
        this.packagetype = "";
        this.image = "";
        this.packageprice = 0;
        this.duration = "";
        this.cab = "NoCab";
        this.breakfast = "NoBreakfast";
        this.sightvisit = "NoSightvisit";
        this.room = "NoRoom";
        this.campfire = "NoCampfire";
        this.meal="NoMeals";
        this.availableSeats ="";
    }
}