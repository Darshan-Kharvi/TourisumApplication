import { Component } from '@angular/core';
import { User } from '../../model/user';
import { UserService } from '../../services/user.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-forgotpassword',
  standalone: false,
  templateUrl: './forgotpassword.component.html',
  styleUrl: './forgotpassword.component.css'
})
export class ForgotpasswordComponent {
  user=new User();
 accountPassword:any;
  npassword:string=" ";
  //find:any;
  constructor(private userservice:UserService,private route:ActivatedRoute,private router:Router){}

  updatepass(){
  console.log(this.user.accountEmail)
  this.userservice.forgotpass(this.user.accountEmail).subscribe(
    (Response:any) => {
     // this.find = Response
     // console.log(Response)
      console.log("checking the username and new password");
        console.log(this.accountPassword);
        console.log(this.npassword);
      if (Response != null) {
        console.log("checking the username and new password");
        console.log(this.accountPassword + " "+this.npassword);
        if (this.npassword == this.accountPassword) {
          this.userservice.updatenewpassbymail(this.user.accountEmail, this.accountPassword,this.user).subscribe(
            Response => {
              console.log(Response)
              alert("PASSWORD SUCCESSFULLY CHANGED")
              this.router.navigate(['signinurl'])
            }
          )
        } else {
          alert("PASSWORD AND CONFIRM PASSWORD DOES NOT MATCH")
        }

      } else {
        alert("EMAIL ID OR FAVOURITE DOES NOT MATCH")

      }
    }
  )

}

}
