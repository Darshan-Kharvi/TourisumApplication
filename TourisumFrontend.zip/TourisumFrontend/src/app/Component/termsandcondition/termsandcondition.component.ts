import { Component } from '@angular/core';

@Component({
  selector: 'app-termsandcondition',
  standalone: false,
  templateUrl: './termsandcondition.component.html',
  styleUrl: './termsandcondition.component.css'
})
export class TermsandconditionComponent {
  isDropdownOpen = false;

  toggleDropdown() {
    this.isDropdownOpen = !this.isDropdownOpen;
  }

  closeDropdown() {
    this.isDropdownOpen = false;
  }
}
