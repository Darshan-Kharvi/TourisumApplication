import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CabbookingComponent } from './cabbooking.component';

describe('CabbookingComponent', () => {
  let component: CabbookingComponent;
  let fixture: ComponentFixture<CabbookingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CabbookingComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CabbookingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
