import { Component, OnInit, ViewChild } from '@angular/core';
import { Cabbooking } from '../../model/cabbooking';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CabbookingService } from '../../services/cabbooking.service';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-cabbooking',
  standalone: false,
  templateUrl: './cabbooking.component.html',
  styleUrl: './cabbooking.component.css'
})
export class CabbookingComponent implements OnInit {
  cabBooking = new Cabbooking();
  user: any;
  userId: any;
  cabId: any;
  cabType: any;
  basePrice: number = 0;
  maxMembers: number = 0;
  isDropdownOpen = false;
  minDate: string = new Date().toISOString().split('T')[0];
  @ViewChild('cabBookingForm') cabBookingForm!: NgForm;

  constructor(
    private route: ActivatedRoute,
    private cabBookingService: CabbookingService,
    private router: Router,
    private userService: UserService
  ) {}

  ngOnInit(): void {
    this.userId = sessionStorage.getItem('userId');
    this.userService.getUserById(this.userId).subscribe((response: any) => {
      this.user = response;
    });

    this.cabId = this.route.snapshot.params['cabId'];
    this.route.queryParams.subscribe(params => {
      this.basePrice = Number(params['price']) || 0;
      this.maxMembers = Number(params['maxMembers']) || 5;
      this.cabBooking.cabType = params['type'] || 'Standard';
    });
  }

  calculatePrice(): void {
    const distance = Number(this.cabBooking.totaldistance) || 0;
    const days = Number(this.cabBooking.totaldays) || 1;
    let price = this.basePrice * distance * days;
    this.cabBooking.price = price.toString();
  }

  submitCabBooking(): void {
    if (this.cabBookingForm.invalid) {
      alert('Please fill all required fields correctly.');
      return;
    }

    const enteredMembers = this.cabBooking.totalMembers || 0;
    const minRequiredMembers = this.maxMembers - 10;

    if (enteredMembers < minRequiredMembers || enteredMembers > this.maxMembers) {
      alert(`Please enter between ${minRequiredMembers} and ${this.maxMembers} members.`);
      return;
    }

    this.cabBookingService.addCabBooking(this.cabBooking, this.userId, this.cabId).subscribe((response: any) => {
      if (response != null) {
        alert('Cab booking successful!');
        sessionStorage.setItem('roomBookingId', response.bookingId);
        this.router.navigate(['/cabbookinganimationurl'], {
          queryParams: {
            bookingId: response.bookingId,
            amount: this.cabBooking.price
          }
        });
      } else {
        alert('Cab booking failed or slot already taken.');
      }
    });
  }


  toggleDropdown() {
    this.isDropdownOpen = !this.isDropdownOpen;
  }

  closeDropdown() {
    this.isDropdownOpen = false;
  }
}
