import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MycabbookingComponent } from './mycabbooking.component';

describe('MycabbookingComponent', () => {
  let component: MycabbookingComponent;
  let fixture: ComponentFixture<MycabbookingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [MycabbookingComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MycabbookingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
