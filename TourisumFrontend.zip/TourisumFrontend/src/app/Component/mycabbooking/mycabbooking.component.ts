import { Component, OnInit } from '@angular/core';
import { Cabbooking } from '../../model/cabbooking';
import { CabbookingService } from '../../services/cabbooking.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-mycabbooking',
  standalone: false,
  templateUrl: './mycabbooking.component.html',
  styleUrl: './mycabbooking.component.css'
})
export class MycabbookingComponent implements OnInit {
  cabBookingId:any;
  cabBookings:any;
  userId:any;
  cab:any;
  bookingId:any;
  isDropdownOpen = false;

  constructor(private cabBookingService:CabbookingService,private route:ActivatedRoute ){}

  ngOnInit(): void {
    this.userId=sessionStorage.getItem('userId');
    console.log(this.userId);
  
    this.cabBookingId=this.route.snapshot.params['id'];
    console.log(this.userId);
     this.cabBookingService.getCabBookingById(this.userId).subscribe(
       (response:any)=>{
         console.log( response);
         this.cabBookings=response;
       }
     )

  }


  // cancelCablBooking(bookingId: any, cab: any) {
  //   this.cabBookingService.cancelCabBooking(bookingId,cab).subscribe( 
  //     (response: any) =>{
  //       if (response != null) {
  //         alert("Status Updated Successfully");
  //       }
  //   });
  // }
 

  cancelCablBooking(bookingId: any, cab: any) {
    if (confirm("Are you sure you want to cancel this booking?")) {
      this.cabBookingService.cancelCabBooking(bookingId, cab).subscribe(
        (response: any) => {
          if (response != null) {
            alert("Status Updated Successfully");
          }
        }
        // ,(error: any) => {
        //   alert("Failed to update status. Please try again.");
        // }
      );
    } else {
      console.log("Booking cancellation was aborted.");
    }
  }

  toggleDropdown() {
    this.isDropdownOpen = !this.isDropdownOpen;
  }
  
  closeDropdown() {
    this.isDropdownOpen = false;
  }
  
  
}
