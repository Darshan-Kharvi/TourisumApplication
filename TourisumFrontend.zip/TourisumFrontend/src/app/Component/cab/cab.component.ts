import { Component, OnInit } from '@angular/core';
import { Cab } from '../../model/cab';
import { CabService } from '../../services/cab.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cab',
  standalone: false,
  templateUrl: './cab.component.html',
  styleUrl: './cab.component.css'
})
export class CabComponent implements OnInit {
cabList:Cab[]=[];
cab=new Cab();
isDropdownOpen = false;
userId:any;

constructor(private cabService:CabService,private router:Router){}

  ngOnInit(): void {
    this.cabService.getAllCabs().subscribe(
      (response:any)=>{
      this.cabList=response;
      });
  }
  booking(cabId:any, cabPrice: number,cabType:any,totalSeats:any){
    this.router.navigate(['/cabbookingurl',cabId] ,{ queryParams: { id: cabId, price: cabPrice,type: cabType,maxMembers:totalSeats } });
  }


  toggleDropdown() {
    this.isDropdownOpen = !this.isDropdownOpen;
  }

  closeDropdown() {
    this.isDropdownOpen = false;
  }

  
}
