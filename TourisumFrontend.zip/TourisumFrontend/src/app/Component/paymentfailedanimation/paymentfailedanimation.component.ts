import { Component } from '@angular/core';

@Component({
  selector: 'app-paymentfailedanimation',
  standalone: false,
  templateUrl: './paymentfailedanimation.component.html',
  styleUrl: './paymentfailedanimation.component.css'
})
export class PaymentfailedanimationComponent {

}
