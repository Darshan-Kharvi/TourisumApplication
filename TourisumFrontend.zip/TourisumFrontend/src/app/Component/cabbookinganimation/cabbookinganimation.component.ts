import { Component } from '@angular/core';

@Component({
  selector: 'app-cabbookinganimation',
  standalone: false,
  templateUrl: './cabbookinganimation.component.html',
  styleUrl: './cabbookinganimation.component.css'
})
export class CabbookinganimationComponent {

}
