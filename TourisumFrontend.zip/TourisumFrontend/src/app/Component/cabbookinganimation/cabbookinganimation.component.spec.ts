import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CabbookinganimationComponent } from './cabbookinganimation.component';

describe('CabbookinganimationComponent', () => {
  let component: CabbookinganimationComponent;
  let fixture: ComponentFixture<CabbookinganimationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CabbookinganimationComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CabbookinganimationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
