import { Component, OnInit } from '@angular/core';
import { Destination } from '../../model/destination';
import { DestinationService } from '../../services/destination.service';

@Component({
  selector: 'app-destination',
  standalone: false,
  templateUrl: './destination.component.html',
  styleUrl: './destination.component.css'
})
export class DestinationComponent implements OnInit{
destinationList: Destination[] = [];
destination = new Destination();

constructor(private destinationservice:DestinationService){}

ngOnInit(): void {
  this.destinationservice.getAllDestination().subscribe(
    (response:any)=>{
      this.destinationList=response;
      console.log(this.destinationList)
    });
}

}
