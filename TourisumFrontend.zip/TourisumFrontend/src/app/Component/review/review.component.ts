import { Component, OnInit } from '@angular/core';
import { Review } from '../../model/review';
import { ReviewService } from '../../services/review.service';
import { Router } from '@angular/router';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-review',
  standalone: false,
  templateUrl: './review.component.html',
  styleUrl: './review.component.css'
})
export class ReviewComponent implements OnInit {

  review =new Review();
  userId: any;
  user:any;
  isDropdownOpen = false;

  constructor(private reviewservice:ReviewService,private userService:UserService,private route:Router){}

  ngOnInit(): void {
    this.userId = sessionStorage.getItem('userId');
    this.userService.getUserById(this.userId).subscribe((response: any) => {
      this.user = response;
    });
  }


  addReview(){
    console.log(this.review);
    this.reviewservice.addReview(this.review, this.userId).subscribe(
      (response:any)=>{
        if(response!=null)
          {
          // console.log(this.destination)
          alert("review adedd sucessfully");
          this.route.navigate(['/homeurl']);
          }else{
            alert("failed");
          }
      });
  }

  toggleDropdown() {
    this.isDropdownOpen = !this.isDropdownOpen;
  }
  
  closeDropdown() {
    this.isDropdownOpen = false;
  }
}
