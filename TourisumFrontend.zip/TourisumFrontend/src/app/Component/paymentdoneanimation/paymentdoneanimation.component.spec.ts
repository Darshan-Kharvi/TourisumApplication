import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentdoneanimationComponent } from './paymentdoneanimation.component';

describe('PaymentdoneanimationComponent', () => {
  let component: PaymentdoneanimationComponent;
  let fixture: ComponentFixture<PaymentdoneanimationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PaymentdoneanimationComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PaymentdoneanimationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
