import { Component } from '@angular/core';

@Component({
  selector: 'app-paymentdoneanimation',
  standalone: false,
  templateUrl: './paymentdoneanimation.component.html',
  styleUrl: './paymentdoneanimation.component.css'
})
export class PaymentdoneanimationComponent {

}
