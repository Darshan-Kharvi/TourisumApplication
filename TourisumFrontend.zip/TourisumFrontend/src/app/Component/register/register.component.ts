import { Component } from '@angular/core';
import { User } from '../../model/user';
import { UserService } from '../../services/user.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-register',
  standalone: false,
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {
  ccpassword:any;
  user = new User();
  isFirstNameValid: boolean = true;
  isLastNameValid: boolean = true;
  emailValid: boolean = true;
  isMobileValid: boolean = true;
  isPasswordValid: boolean = true;
  isAddressValid: boolean = true;
  isFavouriteValid: boolean = true;
  disableSubmit:boolean=true;
  a: any;
  b: any;
  checkemail=new User();
  //create = new User();



  constructor(private userService: UserService,private route:ActivatedRoute,private router:Router){}

// registerUser( inputemail: string,password: string)
// {
//   console.log('Register function called');
//   console.log('Email being checked:', inputemail);



//   console.log(this.registerUser);
//   this.a=this.userService.checkbyemail(inputemail).subscribe(
//     (response:any)=>{
//       this.checkemail=response;
//       console.log(response);
//     })
//     console.log(this.checkemail)
//     if (this.checkemail != null) 
//     {
//       alert("THIS EMAILID OR MOBILE NUMBER ALREADY EXISTS")
//     }else{
//       if (this.ccpassword == password){
//         this.userService.registerUser(this.user).subscribe(
//           (Response:any)=>{
//             console.log(Response);
//             alert("registered sucessfully");
//             this.router.navigate(['signinurl']);
//           })

//       }else{
//         alert("PASSWORD DOES NOT MATCH CONFIRM PASSWORD");
//       }
//     }
// }


registerUser(inputemail: string, password: string) {
  console.log('Register function called');
  console.log('Email being checked:', inputemail);

  this.userService.checkbyemail(inputemail).subscribe((response: any) => {
    this.checkemail = response;
    console.log("Email check response:", response);

    if (this.checkemail != null) {
      alert("THIS EMAIL ID OR MOBILE NUMBER ALREADY EXISTS");
    } else {
      if (this.ccpassword === password) {
        this.userService.registerUser(this.user).subscribe((Response: any) => {
          console.log(Response);
          alert("Registered successfully");
          this.router.navigate(['signinurl']);
        });
      } else {
        alert("PASSWORD DOES NOT MATCH CONFIRM PASSWORD");
      }
    }
  });
}


isRequiredFieldsValid(): boolean {
  return (
    this.user.firstName !== null &&
    this.user.firstName !== undefined &&
    this.user.firstName.trim().length > 1 && // Min 2 characters

    this.user.lastName !== null &&
    this.user.lastName !== undefined &&
    this.user.lastName.trim().length > 0 && // Min 1 character

    this.user.accountEmail !== null &&
    this.user.accountEmail !== undefined &&
    this.validateEmail(this.user.accountEmail) && // Check valid email format

    this.user.password !== null &&
    this.user.password !== undefined &&
    this.user.password.length >= 5 && // Min 5 characters

    this.ccpassword !== null &&
    this.ccpassword !== undefined &&
    this.ccpassword === this.user.password && // Confirm password match

    this.user.phoneNo !== null &&
    this.user.phoneNo !== undefined &&
    this.validatePhone(this.user.phoneNo) && // Check valid phone number

    this.user.address !== null &&
    this.user.address !== undefined &&
    this.user.address.trim().length > 0 // Address should not be empty
  );
}

// Helper function to validate email format
validateEmail(email: string): boolean {
  const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  return emailPattern.test(email);
}

// Helper function to validate phone number format
validatePhone(phone: string): boolean {
  const phonePattern = /^[0-9]{10}$/; // Ensures exactly 10 digits
  return phonePattern.test(phone);
}



firstnamevalid(event: any) {
  event.target.value = event.target.value.trim().length > 0 ? event.target.value : event.target.value.trim(); //
  console.log(event.target.value)
  this.user.firstName = event.target.value
  this.isFirstNameValid = this.user.firstName.match(/^[A-Za-z\s]*$/) && this.user.firstName.length > 2 ? true : false
  console.log(this.isFirstNameValid);
  this.checkValidation();
}
lastnamevalid(event: any) {
  event.target.value = event.target.value.trim().length > 0 ? event.target.value : event.target.value.trim();
  this.user.lastName = event.target.value
  this.isLastNameValid = this.user.lastName.match("^[A-Za-z\s]*$") && this.user.lastName.length > 0 ? true : false
  console.log(this.isLastNameValid);
  this.checkValidation();
}
emailvalid(event: any) {
  event.target.value = event.target.value.trim();
  this.user.accountEmail = event.target.value
  this.emailValid = this.user.accountEmail.match("^[a-zA-Z0-9._-]+@[a-zA-Z0-9-]+\\.[a-zA-Z.]{2,4}$") ? true : false
  console.log(this.emailValid);
  this.checkValidation();
}
mobileValid(event: any) {
  event.target.value = event.target.value.trim();
  this.user.phoneNo = event.target.value
  let m = this.user.phoneNo.split("");
  console.log(m)
  let n = new Set(m);
  console.log(new Set(m));
  console.log(n.size)

  this.isMobileValid = this.user.phoneNo.match(/^[6-9][0-9]{9}$/) && n.size > 2 ? true : false
  console.log(this.isMobileValid)
  this.checkValidation();
}
passwordValid(event: any) {
  event.target.value = event.target.value.trim();
  this.user.password = event.target.value
  this.isPasswordValid = this.user.password.match("^[a-zA-Z0-9._-]+[@|_|&|%|*|$|-][a-zA-Z0-9-]{2,7}$") ? true : false
  console.log(this.passwordValid)
  this.checkValidation();
}
cPasswordValid(event: any) {
  event.target.value = event.target.value.trim();
  this.ccpassword = event.target.value
  this.isPasswordValid = this.ccpassword.match("^[a-zA-Z0-9._-]+[@|_|&|%|*|$|-][a-zA-Z0-9-]{2,7}$") ? true : false
  console.log(this.passwordValid)
  this.checkValidation();
}
addressValid(event: any) {
  event.target.value = event.target.value.trim().length > 0 ? event.target.value : event.target.value.trim();
  this.user.address = event.target.value
  this.isAddressValid = this.user.address.match("^[a-zA-Z0-9. ,-]{15,50}$") ? true : false
  console.log(this.addressValid)
  this.checkValidation();
}
checkValidation(){
  this.disableSubmit=this.isFirstNameValid && this.isLastNameValid && this.isMobileValid && this.emailValid && this.isAddressValid && this.isPasswordValid && this.user.firstName!='' && this.user.lastName!='' && this.user.lastName!='' && this.user.phoneNo!='' && this.user.password!='' && this.ccpassword!='' ?false:true;
  return this.disableSubmit;
}

}
