import { Component, OnInit } from '@angular/core';
import { Room } from '../../model/room';
import { RoomserviceService } from '../../services/roomservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-room',
  standalone: false,
  templateUrl: './room.component.html',
  styleUrl: './room.component.css'
})
export class RoomComponent implements OnInit {
roomList:Room[]=[];
room=new Room();
isDropdownOpen = false;

constructor(private roomservice:RoomserviceService,private router:Router){}
  ngOnInit(): void {
    this.roomservice.getAllRoom().subscribe(
      (response:any)=>{
      this.roomList=response;
      });
  }

  booking(roomId:any, roomPrice: number,roomType:any){
    this.router.navigate(['/roombookingurl',roomId] ,{ queryParams: { id: roomId, price: roomPrice,type: roomType } });
  }

  toggleDropdown() {
    this.isDropdownOpen = !this.isDropdownOpen;
  }
  
  closeDropdown() {
    this.isDropdownOpen = false;
  }
  
}
