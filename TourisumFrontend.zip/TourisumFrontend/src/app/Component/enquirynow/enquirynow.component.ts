import { Component, OnInit } from '@angular/core';
import { Enquiry } from '../../model/enquiry';
import { NgClass } from '@angular/common';
import { EnquiryService } from '../../services/enquiry.service';
import { UserService } from '../../services/user.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-enquirynow',
  standalone: false,
  templateUrl: './enquirynow.component.html',
  styleUrl: './enquirynow.component.css'
})
export class EnquirynowComponent implements OnInit {

  enquiry=new Enquiry();
  destinationId:any;
  user: any = {};
  userId: any;
  destinationLocation:any;
  destinationName:any;
  isDropdownOpen = false;

constructor(private enquiryService:EnquiryService,private userService:UserService,private route:ActivatedRoute,private router:Router){}

ngOnInit(): void {
  this.userId = sessionStorage.getItem('userId');
  this.userService.getUserById(this.userId).subscribe((response: any) => {
  this.user = response;
  });

  this.destinationId = this.route.snapshot.params['id'];
  this.route.queryParams.subscribe(params => {
  this.destinationLocation=params["location"];
  this.destinationName=params["name"];
  this.enquiry.name=this.destinationName;
  this.enquiry.location=this.destinationLocation;
});
}
  
addEnquiry(){

this.enquiryService.addEnquiry(this.enquiry, this.userId, this.destinationId).subscribe(
  (response:any)=>{
    if(response!=null)
      {
      alert("review adedd sucessfully");
      this.router.navigate(['/homeurl']);
      }else{
        alert("failed");
      }
  });

}

toggleDropdown() {
  this.isDropdownOpen = !this.isDropdownOpen;
}

closeDropdown() {
  this.isDropdownOpen = false;
}
}
