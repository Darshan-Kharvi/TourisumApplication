import { Component } from '@angular/core';

@Component({
  selector: 'app-ourteam',
  standalone: false,
  templateUrl: './ourteam.component.html',
  styleUrl: './ourteam.component.css'
})
export class OurteamComponent {
  isDropdownOpen = false;

  toggleDropdown() {
    this.isDropdownOpen = !this.isDropdownOpen;
  }

  closeDropdown() {
    this.isDropdownOpen = false;
  }
}
