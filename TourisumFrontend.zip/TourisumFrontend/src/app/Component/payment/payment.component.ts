import { HttpBackend, HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { paymentService } from '../../services/payment.service';
import { UserService } from '../../services/user.service';
import { Payment } from '../../model/payment';
import { PackagebookingService } from '../../services/packagebooking.service';
import { PackageBooking } from '../../model/pacakagebooking';
import { RoombookingService } from '../../services/roombooking.service';
import { Room } from '../../model/room';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Bankserver } from '../../model/bankserver';

@Component({
  selector: 'app-payment',
  standalone: false,
  templateUrl: './payment.component.html',
  styleUrl: './payment.component.css'
})
export class paymentComponent implements OnInit {
  //amount: number = 0;
  payment = new Payment();
  bookingId:any;
  user:any;
  userId:any;
  roomId:number=0;
  roomPrice:any;
  myGroup:any;
  booking=new PackageBooking();
  room=new Room();
  roomBookingId:any;
  paymentForm!: FormGroup;
  bankserver=new Bankserver();
  paymentButton:boolean=false;


constructor(private paymentservice:paymentService,
  private route:ActivatedRoute,
  private userService:UserService,
  private packagebookingservice:PackagebookingService,
  private roombookingservice:RoombookingService,private router:Router,
  private fb:FormBuilder
){}


ngOnInit(): void {


  this.userId=sessionStorage.getItem('userId');
 this.userService.getUserById(this.userId).subscribe(
  (Response:any)=>
  {
    this.user=Response;
  }
  )


    this.route.queryParams.subscribe(params => {
    this.payment.paymentAmount = params['amount'] ? parseFloat(params['amount']) : 0;

    this.bookingId = params['bookingId']; //  Extract bookingId
    console.log('Extracted bookingId:', this.bookingId);  // Debugging log
    this.roomId=params['roomId'];
    console.log('Extracted roomId:', this.roomId);
    this.roomPrice=params['roomPrice'];
    console.log(this.roomPrice)
  });

  this.paymentForm = this.fb.group({
    cardholderName: ['', [Validators.required, Validators.pattern(/^[A-Za-z\s]+$/)]],
    cardNumber: ['', [Validators.required, this.cardNumberValidator]],
    expiryDate: ['', [Validators.required, this.expiryDateValidator]],
    cvv: ['', [Validators.required, Validators.pattern(/^\d{3}$/)]],
    //paymentAmount: [{ value: this.payment.paymentAmount, disabled: true }, Validators.required] 
  });

}

// Simple Card Number Validation (Only 16 digits)
cardNumberValidator(control: any) {
  const num = control.value.replace(/\s/g, '');
  return /^\d{16}$/.test(num) ? null : { invalidCard: true };
}

// Expiry Date Validation (MM/YY)
expiryDateValidator(control: any) {
  const regex = /^(0[1-9]|1[0-2])\/?([0-9]{2})$/;
  if (!regex.test(control.value)) return { invalidExpiryDate: true };

  const [month, year] = control.value.split('/').map(Number);
  const currentYear = new Date().getFullYear() % 100;
  const currentMonth = new Date().getMonth() + 1;

  if (year < currentYear || (year === currentYear && month < currentMonth)) {
    return { expiredCard: true };
  }
  return null;
}

// Auto-format card number (Adds space every 4 digits)
formatCardNumber() {
  let num = this.paymentForm.get('cardNumber')?.value;
  num = num.replace(/\D/g, '');
  num = num.replace(/(\d{4})/g, '$1 ').trim();
  this.paymentForm.get('cardNumber')?.setValue(num, { emitEvent: false });
}

submitPayment() {
  if (this.paymentForm.invalid) {
    alert("Please fill in all required fields correctly!");
    return;
  }

  this.payment = {
    cardholderName: this.paymentForm.value.cardholderName,
    cardNumber: this.paymentForm.value.cardNumber.replace(/\s/g, ''),
    exipireDate: this.paymentForm.value.expiryDate,
    cvv: this.paymentForm.value.cvv,
    paymentAmount: this.payment.paymentAmount,
    paymentStatus: 'DONE',
    paymentDate: new Date(),
    paymentId: this.paymentForm.value.paymentId
  };

  this.bankserver.cCardnumber = this.payment.cardNumber;
  this.bankserver.cCvvnumber = this.payment.cvv;
  this.bankserver.cCardholdername = this.payment.cardholderName;
  this.bankserver.expiryDate = this.payment.exipireDate;

  //Only proceed if card is valid
  this.paymentservice.getBankServer(this.bankserver).subscribe((response: any) => {
    if (response != null) {
      console.log('Card is valid');
      this.paymentButton = true;

      // Now make the payment
      this.paymentservice.addpayment(this.payment, this.userId, this.bookingId, this.roomId, this.roomPrice).subscribe(
        (response: any) => {
          if (response != null) {
            this.router.navigate(['/paymentdoneanimationurl']);

            if (this.roomId == 0) {
              this.packagebookingservice.updatePackageBookingStatusByBookingId(this.bookingId, this.booking).subscribe(
                (response: any) => {
                  if (response != null) {
                    alert("Status Updated Successfully");
                  }
                }
              );
            } else {
              this.roomBookingId = sessionStorage.getItem('roomBookingId');
              this.roombookingservice.updateRoomBookingStatusByRoomBookingId(this.roomBookingId, this.room).subscribe(
                (response: any) => {
                  if (response != null) {
                    alert("Status Updated Successfully");
                  }
                });
            }
          }
        }
      );

    } else {
      console.log('Invalid card details');
      alert("Invalid Card Details!!");
    }
  });
}

cancelPayment() {
  this.router.navigate(['/paymentfailedanimationurl']); // Replace with your actual route
}

}
