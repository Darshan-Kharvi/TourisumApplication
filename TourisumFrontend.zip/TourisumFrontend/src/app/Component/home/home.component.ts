import { Component, OnInit, AfterViewInit,ElementRef, HostListener } from '@angular/core';
import { UserService } from '../../services/user.service';
import { Destination } from '../../model/destination';
import { DestinationService } from '../../services/destination.service';
import { Review } from '../../model/review';
import { ReviewService } from '../../services/review.service';
import { User } from '../../model/user';
import { Router } from '@angular/router';


@Component({
  selector: 'app-home',
  standalone: false,
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'] // Fixed incorrect property name (styleUrl → styleUrls)
})


export class HomeComponent implements OnInit, AfterViewInit {
  user: any;
  user1=new User();
  reviewList:any;
  userId: any;
  destinationList: Destination[] = [];
  destination = new Destination();
  isDropdownOpen = false;
  review=new Review();
  Math = Math;
  currentSlideIndex = 0;
  reviewsPerPage = 3;
  transitionStyle = 'transform 0.5s ease-in-out';

  constructor(private userService: UserService,private destinationservice:DestinationService,private elementRef: ElementRef,private reviewservice:ReviewService,private router:Router) {}

  getTransform() {
    return `translateX(-${this.currentSlideIndex * 100}%)`;
  }

  ngOnInit(): void {
    this.userId = sessionStorage.getItem('userId');
    if (this.userId) {
      this.userService.getUserById(this.userId).subscribe((response: any) => {
        this.user = response;
      });
      this.destinationservice.getAllDestination().subscribe(
        (response:any)=>{
          this.destinationList=response;
        });
        this.reviewservice.getAllReview().subscribe(
          (response:any)=>{
            this.reviewList=response;
            console.log(this.reviewList)
          });
        // this.reviewservice.getReviewByUserId(this.userId).subscribe(
        // (response:any)=>{
        // this.reviewList=response;
        // console.log(this.reviewList);
        // });
    }
    setInterval(() => {
      const totalPages = Math.ceil(this.reviewList.length / this.reviewsPerPage);
      this.currentSlideIndex = (this.currentSlideIndex + 1) % totalPages;
    }, 10000); // Change slide every 10 seconds
  }

  addEnquiry(destinationId:any,destinationName:any,destinationLocation:any){
    this.router.navigate(['/enquirynowurl',destinationId],{ queryParams: { name:destinationName,location:destinationLocation} });
  }

  ng(): void {
    this.startCounterAnimation();
  }

  startCounterAnimation(): void {
    const counters = document.querySelectorAll('.count');

    counters.forEach(counter => {
      let target = +counter.getAttribute('data-count')!;
      let count = 0;
      let speed = target / 100; // Adjust speed based on target value

      function updateCounter() {
        if (count < target) {
          count += Math.ceil(speed);
          counter.innerHTML = count + "+";
          setTimeout(updateCounter, 30);
        } else {
          counter.innerHTML = target + "+";
        }
      }

      updateCounter();
    });
  }

  ngAfterViewInit(): void {
    this.startCounterAnimation();
  }

  toggleDropdown() {
    this.isDropdownOpen = !this.isDropdownOpen;
  }

  closeDropdown() {
    this.isDropdownOpen = false;
  }

  @HostListener('document:click', ['$event'])
  onClickOutside(event: MouseEvent): void {
    if (!this.elementRef.nativeElement.contains(event.target)) {
      this.closeDropdown();
    }
  }

  customOptions: any = {
    loop: true,
    margin: 10,
    nav: true,
    dots: true,
    responsive: {
      0: { items: 1 },
      600: { items: 1 },
      1000: { items: 2 }
    }
  };
  
  
  
}
