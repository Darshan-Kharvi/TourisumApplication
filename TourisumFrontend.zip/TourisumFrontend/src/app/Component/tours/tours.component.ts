import { Component, OnInit } from '@angular/core';
import { Tours } from '../../model/tours';
import { TourserviceService } from '../../services/tourservice.service';

@Component({
  selector: 'app-tours',
  standalone: false,
  templateUrl: './tours.component.html',
  styleUrl: './tours.component.css'
})
export class ToursComponent implements OnInit {
  tourList:Tours[]=[]
  tour=new Tours();

  constructor(private tourservice:TourserviceService){}
  
  ngOnInit(): void {
    this.tourservice.getAllTours().subscribe(
      (responce:any)=>{
        this.tourList=responce;
      });
  }
}
