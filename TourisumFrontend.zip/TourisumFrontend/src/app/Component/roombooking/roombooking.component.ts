import { Component, OnInit } from '@angular/core';
import { RoomBooking } from '../../model/roombooking';
import { UserService } from '../../services/user.service';
import { ActivatedRoute, Router } from '@angular/router';
import { RoombookingService } from '../../services/roombooking.service';
import { ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';


@Component({
  selector: 'app-roombooking',
  standalone: false,
  templateUrl: './roombooking.component.html',
  styleUrl: './roombooking.component.css'
})
export class RoombookingComponent implements OnInit {
  booking1 = new RoomBooking();
  user: any;
  userId: any;
  roomId: any;
  roomType: any;
  basePrice: number = 0;
  minDate: string = new Date().toISOString().split('T')[0]; // Get today's date
  // checkInDate: any;
  // checkOutDate: any;
  numberOfDays: number = 1;
  paymentButton:boolean=false;
  isDropdownOpen = false;
  @ViewChild('bookingForm') bookingForm!: NgForm; // Capture the form reference

  constructor(
    private userService: UserService,
    private myroombookingservice: RoombookingService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.userId = sessionStorage.getItem('userId');

      this.userService.getUserById(this.userId).subscribe((response: any) => {
      this.user = response;
    });

      this.roomId = this.route.snapshot.params['id'];
      this.route.queryParams.subscribe(params => {
      this.roomType = params['type'];
      this.basePrice = Number(params['price']) || 0;
      this.booking1.price = this.basePrice; // Set initial price
      this.booking1.roomType = this.roomType;
    });

    this.booking1.totalMembers = 0; // Default value
    this.booking1.childrens = 0;
  }


  isRequiredFieldsValid(): boolean {
    return (
      this.booking1.totalMembers != null && this.booking1.totalMembers > 0 &&
      this.booking1.childrens != null && this.booking1.childrens >= 0 &&
      typeof this.booking1.checkinDate === 'string' && 
      !isNaN(Date.parse(this.booking1.checkinDate)), // Ensures valid date
      typeof this.booking1.checkoutDate==='string' &&
      !isNaN(Date.parse(this.booking1.checkoutDate))
    );
  }
  
 updatePrice() {
    let members = Number(this.booking1.totalMembers) || 1;
    let children = Number(this.booking1.childrens) || 0;

    if (members > 2) {
      members = 2;
      this.booking1.totalMembers = 2;
    }
    if (children > 2) {
      children = 2;
      this.booking1.childrens = 2;
    }

  
    if (this.booking1.checkinDate && this.booking1.checkoutDate) {
      const checkIn = new Date(this.booking1.checkinDate);
      const checkOut = new Date(this.booking1.checkoutDate);
  
      // Calculate the number of days
      const timeDiff = checkOut.getTime() - checkIn.getTime();
      this.numberOfDays = Math.max(1, Math.ceil(timeDiff / (1000 * 60 * 60 * 24))); // Ensure at least 1 day
    } else {
      this.numberOfDays = 1; // Default to 1 if no dates selected
    }
  
    // Example pricing logic: children are charged at half price
    this.booking1.price =
      (this.basePrice * members + this.basePrice * 0.5 * children) * this.numberOfDays;
  
    // Ensure price is not negative
    this.booking1.price = Math.max(0, this.booking1.price);

    console.log("Total Days:", this.numberOfDays);
  console.log("Calculated Price:", this.booking1.price);
  }
  
  validateInput(event: any) {
    const value = event.target.value;
    if (value < 1 || value > 2) {
      event.target.value = '';
    }
  }

  validateInputChildren(event: any) {
    const value = event.target.value;
    if (value < 1 || value > 2) {
      event.target.value = '';
    }
  }
  
  

  submitBooking() {
    if (!this.bookingForm) return;
  
    // Mark all form fields as touched so validation messages appear
    Object.values(this.bookingForm.controls).forEach((control) => {
      control.markAsTouched();
    });
  
    // Check if the form is invalid
    if (this.bookingForm.invalid||this.booking1.totalMembers==0) {
      alert('Please fill all required fields correctly before submitting.');
      return;
    }
  
    // Additional validation for check-in and check-out date
    if (!this.booking1.checkinDate || !this.booking1.checkoutDate) {
      alert('Please select both Check-in and Check-out dates.');
      return;
    }

    // const checkinDate = new Date(this.booking1.checkinDate);
    // const checkoutDate = new Date(this.booking1.checkoutDate);

    // if (isNaN(checkinDate.getTime()) || isNaN(checkoutDate.getTime())) {
    //   alert("Invalid date selection.");
    //   return;
    // }
  
    if (new Date(this.booking1.checkoutDate) <= new Date(this.booking1.checkinDate)) {
      alert('Check-out date must be after Check-in date.');
      return;
    }
    
    
     
    // Proceed with booking submission
    this.myroombookingservice.addRoomBooking(this.booking1, this.userId, this.roomId).subscribe((response: any) => {
      if (response != null) {
        alert('Booking Successful. Proceed to Payment.');
        sessionStorage.setItem('roomBookingId', response.bookingId);
        this.router.navigate(['/paymenturl'], {
          queryParams: {
            amount: this.booking1.price,
            userId: this.userId,
            bookingId: response.bookingId,
            roomId: this.roomId,
            roomPrice: this.booking1.price
          }
        });
      }else{
        alert('This Dates are already Booked Please Chose Anothor Dates')
      }
    });
  }
  
  // validateDate(event:any)
  // {

  // }
  


  toggleDropdown() {
    this.isDropdownOpen = !this.isDropdownOpen;
  }

  closeDropdown() {
    this.isDropdownOpen = false;
  }

}
