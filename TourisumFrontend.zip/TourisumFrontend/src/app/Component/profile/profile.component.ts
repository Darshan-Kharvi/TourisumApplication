import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user.service';
import { ActivatedRoute, Router } from '@angular/router';
import { User } from '../../model/user';

@Component({
  selector: 'app-profile',
  standalone: false,
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.css'
})
export class ProfileComponent implements OnInit {
userId:any;
user= new User();
isDropdownOpen = false;


  constructor(private userservice:UserService,private route:ActivatedRoute,private router:Router){}
  ngOnInit(): void {
    this.userId=this.route.snapshot.params['id'];
    this.userservice.getUserById(this.userId).subscribe(
      (response:any) =>{
        this.user=response;
      });
  }

  editProfile(){
    this.router.navigate(['/editprofileurl',this.userId]);
  }

  logout() {
    localStorage.removeItem('token'); // Remove auth token or session
    localStorage.removeItem('userId'); // If stored separately
    this.router.navigate(['/']); // Redirect to login page
  }


  toggleDropdown() {
    this.isDropdownOpen = !this.isDropdownOpen;
  }

  closeDropdown() {
    this.isDropdownOpen = false;
  }


}

