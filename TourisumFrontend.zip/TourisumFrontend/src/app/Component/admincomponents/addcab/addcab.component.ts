import { Component } from '@angular/core';
import { Cab } from '../../../model/cab';
import { CabService } from '../../../services/cab.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-addcab',
  standalone: false,
  templateUrl: './addcab.component.html',
  styleUrl: './addcab.component.css'
})
export class AddcabComponent {
cab =new Cab();

constructor(private cabService:CabService,private route:Router){}

addCab(){
  console.log(this.cab);
  this.cabService.addCab(this.cab).subscribe(
    (response:any)=>{
      if(Response!=null)
        {
        alert("cab adedd sucessfully");
        this.route.navigate(['/adminhomeurl']);
        }else{
          alert("failed");
        }
    });
}

}
