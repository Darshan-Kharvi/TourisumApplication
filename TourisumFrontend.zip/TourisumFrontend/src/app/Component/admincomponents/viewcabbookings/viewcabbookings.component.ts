import { Component, OnInit } from '@angular/core';
import { Cabbooking } from '../../../model/cabbooking';
import { CabbookingService } from '../../../services/cabbooking.service';

@Component({
  selector: 'app-viewcabbookings',
  standalone: false,
  templateUrl: './viewcabbookings.component.html',
  styleUrl: './viewcabbookings.component.css'
})
export class ViewcabbookingsComponent implements OnInit {
cabBookingList:any;
cabBooking=new Cabbooking();
user:any;
cab:any;
a:any;

constructor(private cabbookingService:CabbookingService){}

ngOnInit(): void {
  this.cabbookingService.getAllCabBookings().subscribe(
    (response:any)=>{
      this.cabBookingList=response;
    });
}

deleteCabBooking(cabBookingId:any)
{
  this.a = confirm('ARE YOU SURE TO DELETE THIS PRODUCT');
  if (this.a == true){
    console.log(cabBookingId);
    this.cabbookingService.deleteCabBooking(cabBookingId).subscribe(
      (response:any)=>{
        this.cabBookingList=response;
        console.log(response);
      });
      alert('BOOKING IS DELETED');
  }else{
    alert('YOU DECIDED NOT TO DELETE BOOKING');
  }


}
}
