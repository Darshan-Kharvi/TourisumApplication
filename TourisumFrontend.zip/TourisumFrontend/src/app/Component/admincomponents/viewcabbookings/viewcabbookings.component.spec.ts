import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewcabbookingsComponent } from './viewcabbookings.component';

describe('ViewcabbookingsComponent', () => {
  let component: ViewcabbookingsComponent;
  let fixture: ComponentFixture<ViewcabbookingsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ViewcabbookingsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewcabbookingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
