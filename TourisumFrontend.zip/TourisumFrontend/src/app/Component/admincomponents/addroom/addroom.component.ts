import { Component } from '@angular/core';
import { Room } from '../../../model/room';
import { RoomserviceService } from '../../../services/roomservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-addroom',
  standalone: false,
  templateUrl: './addroom.component.html',
  styleUrl: './addroom.component.css'
})
export class AddroomComponent {
room=new Room();
breakfastflag:boolean=false;
mealflag:boolean=false;
campfireflag:boolean=false;
constructor(private roomservice:RoomserviceService,private route:Router){}

onBreakfast(event: any)
{
if(this.breakfastflag===true)
{
  this.room.breakfast="BreakFast";
}else{
this.room.breakfast="No Breakfast";
}
}
onMeal(event: any)
{
  if(this.mealflag===true)
    {
      this.room.meal="Meal";
    }else{
    this.room.meal="No Meal";
    }
}
onCampfire(event: any)
{
  if(this.campfireflag===true)
    {
      this.room.campfire="CampFire";
    }else{
    this.room.campfire="No CampFire";
    }
}

addRoom() {
  // Basic manual validation check before submission
  if (!this.room.roomName || 
      !this.room.location || 
      !this.room.price || 
      !this.room.description || 
      !this.room.duration || 
      !this.room.roomtype || 
      !this.room.image) {
    alert('Please fill out all required fields.');
    return;
  }

  console.log(this.room);

  this.roomservice.addRoom(this.room).subscribe(
    (response: any) => {
      if (response != null) {
        alert("Room added successfully");
        this.route.navigate(['/adminhomeurl']);
      } else {
        alert("Failed to add room");
      }
    },
    (error) => {
      console.error("Error while adding room:", error);
      alert("Something went wrong");
    }
  );
}

}
