import { Component } from '@angular/core';
import { Package } from '../../../model/package';
import { PackageserviceService } from '../../../services/packageservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-addpackage',
  standalone: false,
  templateUrl: './addpackage.component.html',
  styleUrl: './addpackage.component.css'
})
export class AddpackageComponent {
packages=new Package()
roomflag:boolean=false;
breakfastflag:boolean=false;
mealflag:boolean=false;
campfireflag:boolean=false;
cabflag:boolean=false;
sightvisitflag:boolean=false;

constructor(private packageservice:PackageserviceService,private route:Router){}

onRoom(event: any)
{
if(this.roomflag===true)
{
  this.packages.room="Room";
}else{
  this.packages.room="NoRoom";
}
}
onBreakfast(event: any)
{
if(this.breakfastflag===true)
{
  this.packages.breakfast="BreakFast";
}else{
this.packages.breakfast="No Breakfast";
}
}
onMeal(event: any)
{
  if(this.mealflag===true)
    {
      this.packages.meal="Meal";
    }else{
    this.packages.meal="No Meal";
    }
}
onCampfire(event: any)
{
  if(this.campfireflag===true)
    {
      this.packages.campfire="CampFire";
    }else{
    this.packages.campfire="No CampFire";
    }
}

onCab(event: any)
{
  if(this.cabflag===true)
    {
      this.packages.cab="Cab";
    }else{
    this.packages.cab="No Cab";
    }
}

onSightvisit(event: any)
{
  if(this.sightvisitflag===true)
    {
      this.packages.sightvisit="SightVisit";
    }else{
    this.packages.sightvisit="No SightVisit";
    }
}




addPackage(){
  console.log(this.packages);
  this.packageservice.addPackage(this.packages).subscribe(
    (response:any)=>{
      if(Response!=null)
        {
        alert("Package adedd sucessfully");
        this.route.navigate(['/adminhomeurl']);
        }else
        alert("failed");
    }
  )
}
}
