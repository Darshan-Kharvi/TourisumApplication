import { Component, OnInit } from '@angular/core';
import { Cab } from '../../../model/cab';
import { CabService } from '../../../services/cab.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-viewcab',
  standalone: false,
  templateUrl: './viewcab.component.html',
  styleUrl: './viewcab.component.css'
})
export class ViewcabComponent implements OnInit {
cabList:Cab[]=[];
cab=new Cab();
a:any;


constructor(private cabService:CabService,private router:Router){}

ngOnInit(): void {
  this.cabService.getAllCabs().subscribe(
    (response:any)=>{
      this.cabList=response;
    });
}

deleteCab(cabId:any){
  this.a = confirm('ARE YOU SURE TO DELETE THIS CAB');
  if (this.a == true){
    console.log(cabId);
    this.cabService.deleteCab(cabId).subscribe(
      (response:any)=>{
        this.cabList=response;
        console.log(response);
      });
      alert('CAB IS DELETED');
  }else{
    alert('YOU DECIDED NOT TO DELETE CAB')
  }
}

updateCab(cabId:any)
{
  this.router.navigate(['/updatecaburl',cabId]);
}
}

