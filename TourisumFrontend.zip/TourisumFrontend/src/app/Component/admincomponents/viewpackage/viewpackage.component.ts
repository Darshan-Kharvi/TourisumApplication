import { Component, OnInit } from '@angular/core';
import { Package } from '../../../model/package';
import { PackageserviceService } from '../../../services/packageservice.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-viewpackage',
  standalone: false,
  templateUrl: './viewpackage.component.html',
  styleUrl: './viewpackage.component.css'
})
export class ViewpackageComponent implements OnInit {
packageList:Package[]=[];
packages=new Package();
a:any;
constructor(private packageservice:PackageserviceService,private route:ActivatedRoute,private router:Router){}

ngOnInit(): void {
  this.packageservice.getAllPackage().subscribe(
    (response:any)=>{
      this.packageList=response;
    });
}
deletePackage(pacakgeId:any){
  this.a = confirm('ARE YOU SURE TO DELETE THIS PACKAGE');
  if (this.a == true){
    console.log(pacakgeId)
    this.packageservice.deletePackage(pacakgeId).subscribe(
      (response:any)=>{
        this.packageList=response;
        console.log(response);
      });
      alert('PACKAGE IS DELETED');
  }else{
    alert('YOU DECIDED NOT TO DELETE PACKAGE');
  }
}
updatePackage(packageId:any)
{
  this.router.navigate(['/updatepackageurl',packageId]);
}

}
