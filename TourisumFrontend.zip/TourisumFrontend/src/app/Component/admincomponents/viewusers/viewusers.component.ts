import { Component, OnInit } from '@angular/core';
import { User } from '../../../model/user';
import { UserService } from '../../../services/user.service';

@Component({
  selector: 'app-viewusers',
  standalone: false,
  templateUrl: './viewusers.component.html',
  styleUrl: './viewusers.component.css'
})
export class ViewusersComponent implements OnInit{
users:User[]=[]
user=new User();
a:any;

constructor(private userservice:UserService){}

ngOnInit(): void {
  this.userservice.getAllUser().subscribe(
    (Response:any)=>{
      this.users=Response
    }
  )
}
userDelete(userId:any){
  this.a = confirm('ARE YOU SURE TO DELETE THIS PRODUCT');
  if (this.a == true) {
    console.log(userId)
  this.userservice.deleteuser(userId).subscribe(
    (response:any)=>{
      this.users=response;
      console.log(response);
    }
    
  );
  alert('USER IS DELETED');
}else{
  alert('YOU DECIDED NOT TO DELETE PRODUCT');
}
}
}
