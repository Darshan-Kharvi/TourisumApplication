import { Component, OnInit } from '@angular/core';
import { paymentService } from '../../../services/payment.service';
import { Payment } from '../../../model/payment';

@Component({
  selector: 'app-viewuserpayments',
  standalone: false,
  templateUrl: './viewuserpayments.component.html',
  styleUrl: './viewuserpayments.component.css'
})
export class ViewuserpaymentsComponent implements OnInit {
paymentList:any;
payment=new Payment();
constructor(private paymentservice:paymentService){}

  ngOnInit(): void {
    this.paymentservice.getAllPayments().subscribe(
      (response:any)=>{
        this.paymentList=response;
      });
    }

}
