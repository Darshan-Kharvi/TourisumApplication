import { Component } from '@angular/core';
import { DestinationService } from '../../../services/destination.service';
import { Destination } from '../../../model/destination';
import { Router } from '@angular/router';

@Component({
  selector: 'app-adddestination',
  standalone: false,
  templateUrl: './adddestination.component.html',
  styleUrl: './adddestination.component.css'
})
export class AdddestinationComponent {

destination = new Destination();
  constructor( private destinationservice:DestinationService,private route:Router){}

  adddestination(){
    console.log(this.destination);
    this.destinationservice.addDestination(this.destination).subscribe(
      (Response:any)=>
        {
          if(Response!=null)
          {
          // console.log(this.destination)
          alert("destinatioan adedd sucessfully");
          this.route.navigate(['/adminhomeurl']);
          }else
          alert("failed");
        }
    );
  }
 
}
