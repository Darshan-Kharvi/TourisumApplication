import { Component } from '@angular/core';
import { UserService } from '../../../services/user.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-adminlogin',
  standalone: false,
  templateUrl: './adminlogin.component.html',
  styleUrl: './adminlogin.component.css'
})
export class AdminloginComponent {
adminemail:any;
adminpassword:any;
flag:boolean=false;
constructor(private user:UserService,private route:ActivatedRoute,private router:Router){}

adminlogin(){
console.log(this.adminemail,this.adminpassword)
this.flag=this.user.adminLogin(this.adminemail,this.adminpassword);
if(this.flag){
console.log("login sucess");
alert("login sucessfull");
this.router.navigate(['adminhomeurl']);
}else{
  alert("login failed");
}


}
}
