import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewpackagebookingsComponent } from './viewpackagebookings.component';

describe('ViewpackagebookingsComponent', () => {
  let component: ViewpackagebookingsComponent;
  let fixture: ComponentFixture<ViewpackagebookingsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ViewpackagebookingsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewpackagebookingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
