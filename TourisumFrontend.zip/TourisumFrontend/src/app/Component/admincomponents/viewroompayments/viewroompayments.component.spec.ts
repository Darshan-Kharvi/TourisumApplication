import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewroompaymentsComponent } from './viewroompayments.component';

describe('ViewroompaymentsComponent', () => {
  let component: ViewroompaymentsComponent;
  let fixture: ComponentFixture<ViewroompaymentsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ViewroompaymentsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewroompaymentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
