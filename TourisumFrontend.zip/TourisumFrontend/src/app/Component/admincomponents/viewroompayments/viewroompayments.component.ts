import { Component } from '@angular/core';
import { Payment } from '../../../model/payment';
import { paymentService } from '../../../services/payment.service';

@Component({
  selector: 'app-viewroompayments',
  standalone: false,
  templateUrl: './viewroompayments.component.html',
  styleUrl: './viewroompayments.component.css'
})
export class ViewroompaymentsComponent {
paymentList:any;
payment=new Payment();
constructor(private paymentservice:paymentService){}



ngOnInit(): void {
  this.paymentservice.getAllRoomPayments().subscribe(
    (response:any)=>{
      this.paymentList=response;
    });
  }


}
