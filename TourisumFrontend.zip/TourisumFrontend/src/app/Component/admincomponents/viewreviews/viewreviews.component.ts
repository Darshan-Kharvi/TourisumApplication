import { Component, OnInit } from '@angular/core';
import { Review } from '../../../model/review';
import { ReviewService } from '../../../services/review.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-viewreviews',
  standalone: false,
  templateUrl: './viewreviews.component.html',
  styleUrl: './viewreviews.component.css'
})
export class ViewreviewsComponent implements OnInit {
reviewList:any;
review=new Review();
a:any;

constructor(private reviewService:ReviewService,private router:Router){}

  ngOnInit(): void {
    this.reviewService.getAllReview().subscribe(
      (response:any)=>{
        this.reviewList=response;
        console.log(this.reviewList);
      });
  }

  deleteReview(reviewId:any){
    this.a = confirm('ARE YOU SURE TO DELETE THIS REVIEW');
    if (this.a == true){
      console.log(reviewId);
      this.reviewService.deleteReview(reviewId).subscribe(
        (response:any)=>{
          this.reviewList=response;
          console.log(response);
        });
        alert('REVIEW IS DELETED');
    }else{
      alert('YOU DECIDED NOT TO DELETE REVIEW')
    }
  }
}
