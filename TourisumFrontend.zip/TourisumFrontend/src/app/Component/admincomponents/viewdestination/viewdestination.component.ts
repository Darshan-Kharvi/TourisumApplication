import { ChangeDetectorRef, Component, OnInit, resource } from '@angular/core';
import { DestinationService } from '../../../services/destination.service';
import { Destination } from '../../../model/destination';
import { Router } from '@angular/router';

@Component({
  selector: 'app-viewdestination',
  standalone: false,
  templateUrl: './viewdestination.component.html',
  styleUrl: './viewdestination.component.css',
})
export class ViewdestinationComponent implements OnInit {
  destinationList: Destination[] = [];
  dest = new Destination();
  a: boolean = false;
  constructor(private destinationservice: DestinationService,private cdRef:ChangeDetectorRef,private router:Router) {}

  ngOnInit(): void {
    this.destinationservice.getAllDestination().subscribe((Response: any) => {
      this.destinationList= Response;
    });
  }
  updateDestination(destId:any) {
    this.router.navigate(['/updatedestinationurl',destId]);

  }

  deleteDestination(destinationId: any) {
    this.a = confirm('ARE YOU SURE TO DELETE THIS PRODUCT');
    if (this.a == true) {
      console.log(destinationId);
      this.destinationservice.deleteDestination(destinationId).subscribe(
        (Response: any) => {
          this.destinationList = Response;
          console.log(Response);
          this.cdRef.detectChanges();
        });
      alert('PRODUCT IS DELETED');
      
    } else {
      alert('YOU DECIDED NOT TO DELETE PRODUCT');
    }
  }
}
