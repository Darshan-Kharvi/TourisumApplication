import { Component, OnInit } from '@angular/core';
import { Enquiry } from '../../../model/enquiry';
import { EnquiryService } from '../../../services/enquiry.service';

@Component({
  selector: 'app-viewenquirys',
  standalone: false,
  templateUrl: './viewenquirys.component.html',
  styleUrl: './viewenquirys.component.css'
})
export class ViewenquirysComponent implements OnInit {
enquiryList:any;
enquiry=new Enquiry();
a:any;

constructor(private enquiryService:EnquiryService){}
ngOnInit(): void {
  this.enquiryService.getAllEnquiry().subscribe(
    (response:any)=>{
      this.enquiryList=response;
      console.log(this.enquiryList);
    });
}
deleteenquiry(enquiryId:any)
{
  this.a = confirm('ARE YOU SURE TO DELETE THIS ENQUIRY');
  if (this.a == true){
    console.log(enquiryId);
    this.enquiryService.deleteEnquiry(enquiryId).subscribe(
      (response:any)=>{
        this.enquiryList=response;
        console.log(response);
      });
      alert('enquiry IS DELETED');
  }else{
    alert('YOU DECIDED NOT TO DELETE ENQUIRY')
  }
}
}
