import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewenquirysComponent } from './viewenquirys.component';

describe('ViewenquirysComponent', () => {
  let component: ViewenquirysComponent;
  let fixture: ComponentFixture<ViewenquirysComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ViewenquirysComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewenquirysComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
