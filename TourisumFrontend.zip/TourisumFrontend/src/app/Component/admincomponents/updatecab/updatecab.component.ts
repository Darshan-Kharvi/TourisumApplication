import { Component, OnInit } from '@angular/core';
import { CabService } from '../../../services/cab.service';
import { ActivatedRoute, Route, Router } from '@angular/router';

@Component({
  selector: 'app-updatecab',
  standalone: false,
  templateUrl: './updatecab.component.html',
  styleUrl: './updatecab.component.css'
})
export class UpdatecabComponent implements OnInit {
  cab: any = {};
  cabId!: number;

  constructor(
    private cabService: CabService,private route: ActivatedRoute,private router: Router) {}

  ngOnInit(): void {
    this.cabId = this.route.snapshot.params['cabId']; // Assuming route is like /updatecab/:cId
    this.cabService.getCabById(this.cabId).subscribe((response: any) => {
    this.cab = response;
    });
  }

  onSubmit() {
    this.cabService.updateCab(this.cabId, this.cab).subscribe(() => {
      alert('Cab Updated Successfully');
      this.router.navigate(['/viewcaburl']);
    });
  }
}
