import { Component, OnInit } from '@angular/core';
import { Room } from '../../../model/room';
import { UserService } from '../../../services/user.service';
import { RoomserviceService } from '../../../services/roomservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-viewroom',
  standalone: false,
  templateUrl: './viewroom.component.html',
  styleUrl: './viewroom.component.css'
})
export class ViewroomComponent implements OnInit {
roomList:Room[]=[];
room=new Room();
a:any;

constructor(private roomservice:RoomserviceService,private router:Router){}
ngOnInit(): void {
  this.roomservice.getAllRoom().subscribe(
    (response:any)=>{
      this.roomList=response;
    });
}
deleteRoom(roomId:any){
  this.a = confirm('ARE YOU SURE TO DELETE THIS PRODUCT');
  if (this.a == true){
    console.log(roomId);
    this.roomservice.deleteRoom(roomId).subscribe(
      (response:any)=>{
        this.roomList=response;
        console.log(response);
      });
      alert('ROOM IS DELETED');
  }else{
    alert('YOU DECIDED NOT TO DELETE ROOM')
  }
}


updateRoom(roomId:any)
{
  this.router.navigate(['/updateroomurl',roomId]);
}
}
