import { Component, OnInit } from '@angular/core';
import { RoomserviceService } from '../../../services/roomservice.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-updateroom',
  standalone:false,
  templateUrl: './updateroom.component.html',
  styleUrls: ['./updateroom.component.css']
})
export class UpdateroomComponent implements OnInit {
  room: any = {};
  roomId!: number;
  breakfastflag: boolean = false;
  mealflag: boolean = false;
  campfireflag: boolean = false;

  constructor(
    private roomservice: RoomserviceService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.roomId = this.route.snapshot.params['rId'];
    this.roomservice.getRoomById(this.roomId).subscribe((response: any) => {
      this.room = response;

      // Initialize checkbox flags based on room data
      this.breakfastflag = this.room.breakfast === "BreakFast";
      this.mealflag = this.room.meal === "Meal";
      this.campfireflag = this.room.campfire === "CampFire";
      console.log(this.breakfastflag)
      console.log(this.mealflag)
      console.log(this.campfireflag)
    });
  }

  onBreakfast(event: any) {
    this.room.breakfast = this.breakfastflag ? "BreakFast" : "No Breakfast";
  }

  onMeal(event: any) {
    this.room.meal = this.mealflag ? "Meal" : "No Meal";
  }

  onCampfire(event: any) {
    this.room.campfire = this.campfireflag ? "CampFire" : "No CampFire";
  }

  onSubmit() {
    this.roomservice.updateRoom(this.roomId, this.room).subscribe(() => {
      alert('Room Updated Successfully');
      this.router.navigate(['/viewroomurl']);
    });
  }
}
