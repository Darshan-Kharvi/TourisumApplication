import { Component, OnInit } from '@angular/core';
import { TourserviceService } from '../../../services/tourservice.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-updatetours',
  standalone: false,
  templateUrl: './updatetours.component.html',
  styleUrl: './updatetours.component.css'
})
export class UpdatetoursComponent implements OnInit {
tours:any;
tourId:any;

constructor(private tourservice:TourserviceService,private route:ActivatedRoute,private router:Router){}

ngOnInit(): void {
  this.tourId=this.route.snapshot.params['tourId'];

  this.tourservice.getToursById(this.tourId).subscribe(
    (response:any) =>{
      this.tours=response;
    });
}
onSubmit(){
  this.tourservice.updateTour(this.tourId,this.tours).subscribe(
    () =>{
      alert('Tours Updated Successfully');
      this.router.navigate(['/viewtoursurl']);
    });
}

}
