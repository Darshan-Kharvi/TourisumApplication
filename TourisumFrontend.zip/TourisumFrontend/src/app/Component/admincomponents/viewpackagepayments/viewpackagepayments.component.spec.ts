import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewpackagepaymentsComponent } from './viewpackagepayments.component';

describe('ViewpackagepaymentsComponent', () => {
  let component: ViewpackagepaymentsComponent;
  let fixture: ComponentFixture<ViewpackagepaymentsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ViewpackagepaymentsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewpackagepaymentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
