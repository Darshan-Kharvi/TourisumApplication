import { Component } from '@angular/core';
import { Payment } from '../../../model/payment';
import { paymentService } from '../../../services/payment.service';

@Component({
  selector: 'app-viewpackagepayments',
  standalone: false,
  templateUrl: './viewpackagepayments.component.html',
  styleUrl: './viewpackagepayments.component.css'
})
export class ViewpackagepaymentsComponent {
paymentList:any;
payment=new Payment();
constructor(private paymentservice:paymentService){}



ngOnInit(): void {
  this.paymentservice.getAllPackagePayments().subscribe(
    (response:any)=>{
      this.paymentList=response;
    });
  }

}
