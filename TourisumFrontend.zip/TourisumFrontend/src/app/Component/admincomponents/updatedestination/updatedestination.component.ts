import { Component, OnInit } from '@angular/core';
import { DestinationService } from '../../../services/destination.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Destination } from '../../../model/destination';

@Component({
  selector: 'app-updatedestination',
  standalone: false,
  templateUrl: './updatedestination.component.html',
  styleUrl: './updatedestination.component.css'
})
export class UpdatedestinationComponent implements OnInit{
destination:any;
destinationId!: number;

constructor(private destinationservice:DestinationService,private route:ActivatedRoute,private router:Router){}

ngOnInit(): void {
  this.destinationId= this.route.snapshot.params['destId'];

  this.destinationservice.getDestinationById(this.destinationId).subscribe(
    (response:any) => {
    this.destination=response;
  });
}

onSubmit() {
  this.destinationservice.updateDestination(this.destinationId, this.destination).subscribe(() => {
    alert('Destination Updated Successfully');
    this.router.navigate(['/viewdestinationurl']); // Navigate back to the list
  });
}

}
