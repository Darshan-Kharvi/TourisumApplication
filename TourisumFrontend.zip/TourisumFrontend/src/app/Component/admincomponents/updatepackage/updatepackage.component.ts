import { Component, OnInit } from '@angular/core';
import { PackageserviceService } from '../../../services/packageservice.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Package } from '../../../model/package';

@Component({
  selector: 'app-updatepackage',
  standalone: false,
  templateUrl: './updatepackage.component.html',
  styleUrl: './updatepackage.component.css'
})
export class UpdatepackageComponent implements OnInit {
packages=new Package();
packageId:any;
roomflag:boolean=false;
breakfastflag:boolean=false;
mealflag:boolean=false;
campfireflag:boolean=false;
cabflag:boolean=false;
sightvisitflag:boolean=false;


constructor(private packageservice:PackageserviceService,private route:ActivatedRoute,private router:Router){}

onBreakfast(event: any) {
  this.packages.breakfast = this.breakfastflag ? "BreakFast" : "No Breakfast";
}

onMeal(event: any) {
  this.packages.meal = this.mealflag ? "Meal" : "No Meal";
}

onCampfire(event: any) {
  this.packages.campfire = this.campfireflag ? "CampFire" : "No CampFire";
}

onRoom(event:any){
  this.packages.room=this.roomflag ? "Room":"No Room";
}

onCab(event:any){
  this.packages.cab=this.cabflag ? "Cab":"No Cab";
}

onSightvisit(event:any){
  this.packages.sightvisit=this.sightvisitflag ? "SightVist":"No SightVisit";
}



ngOnInit(): void {
  this.packageId=this.route.snapshot.params['packageId'];

  this.packageservice.getPacakgeById(this.packageId).subscribe(
    (response:any)=>{
      this.packages=response;
      console.log(this.packages);
      this.breakfastflag = this.packages.breakfast === "BreakFast";
      console.log(this.packages.breakfast);
      this.mealflag = this.packages.meal === "Meal";
      this.campfireflag = this.packages.campfire === "CampFire";
      this.cabflag=this.packages.cab==="Cab";
      this.roomflag=this.packages.room==="Room";
      this.sightvisitflag=this.packages.sightvisit==="SightVisit";
      console.log(this.breakfastflag)
      console.log(this.mealflag)
      console.log(this.campfireflag)
      console.log(this.cabflag)
      console.log(this.roomflag)
      console.log(this.sightvisitflag)
    });
}

onSubmit(){
  this.packageservice.updatePackage(this.packageId,this.packages).subscribe(
    ()=>{
      alert('Package Updated Successfully');
      this.router.navigate(['/viewpackageurl']);
    });
}
}
