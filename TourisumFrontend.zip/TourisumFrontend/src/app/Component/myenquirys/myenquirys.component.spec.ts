import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MyenquirysComponent } from './myenquirys.component';

describe('MyenquirysComponent', () => {
  let component: MyenquirysComponent;
  let fixture: ComponentFixture<MyenquirysComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [MyenquirysComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MyenquirysComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
