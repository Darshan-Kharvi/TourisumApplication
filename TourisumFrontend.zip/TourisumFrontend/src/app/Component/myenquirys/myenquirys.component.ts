import { Component, OnInit } from '@angular/core';
import { Enquiry } from '../../model/enquiry';
import { EnquiryService } from '../../services/enquiry.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-myenquirys',
  standalone: false,
  templateUrl: './myenquirys.component.html',
  styleUrl: './myenquirys.component.css'
})
export class MyenquirysComponent implements OnInit {

enquiry=new Enquiry();
enquiryList:any;
userId:any;
enquiryId:any
isDropdownOpen = false;

constructor(private enquiryService:EnquiryService,private route:ActivatedRoute){}

ngOnInit(): void {
  this.userId=sessionStorage.getItem('userId');
    console.log(this.userId);
  
    this.enquiryId=this.route.snapshot.params['id'];
    console.log(this.userId);
     this.enquiryService.getEnquiryById(this.userId).subscribe(
       (response:any)=>{
         console.log( response);
         this.enquiryList=response;
       }
     )
}

toggleDropdown() {
  this.isDropdownOpen = !this.isDropdownOpen;
}

closeDropdown() {
  this.isDropdownOpen = false;
}

}
