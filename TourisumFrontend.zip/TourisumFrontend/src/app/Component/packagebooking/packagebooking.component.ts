import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { PackageBooking } from '../../model/pacakagebooking';
import { PackagebookingService } from '../../services/packagebooking.service';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-packagebooking',
  templateUrl: './packagebooking.component.html',
  standalone: false,
  styleUrl: './packagebooking.component.css'
})
export class PackagebookingComponent implements OnInit {
  booking = new PackageBooking();
  packageId: any | null = null;
  basePrice: number = 0;
  user: any = {};
  userId: any;
  roomId: number = 0;
  roomPrice: number = 0;
  minDate: string = '';
  maxMembers: number = 0;
  isDropdownOpen = false;

  constructor(
    private userService: UserService,
    private packagebookingservice: PackagebookingService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    const today = new Date();
    this.minDate = today.toISOString().split('T')[0];

    this.userId = sessionStorage.getItem('userId');
    this.userService.getUserById(this.userId).subscribe((response: any) => {
      this.user = response;
    });

    this.packageId = this.route.snapshot.params['id'];
    this.route.queryParams.subscribe((params) => {
      this.basePrice = Number(params['price']) || 0;
      this.maxMembers = Number(params['maxseats']) || 5;
      this.booking.price = this.basePrice;
    });
  }

  isRequiredFieldsValid(): boolean {
    const totalMembers = Number(this.booking.totalMembers);
    const children = Number(this.booking.childrens);
    const totalParticipants = totalMembers + children;
    const minRequired = this.maxMembers - 5;

    return (
      !isNaN(totalMembers) &&
      !isNaN(children) &&
      totalMembers >= 0 &&
      children >= 0 &&
      totalParticipants >= minRequired &&
      totalParticipants <= this.maxMembers &&
      this.booking.picupLocation?.trim().length > 0 &&
      typeof this.booking.bookingDate === 'string' &&
      !isNaN(Date.parse(this.booking.bookingDate))
    );
  }

  updatePrice() {
    let members = Number(this.booking.totalMembers);
    let children = Number(this.booking.childrens);

    if (isNaN(members) || members < 0) {
      members = 0;
    } else if (members > this.maxMembers) {
      members = this.maxMembers;
    }

    if (isNaN(children) || children < 0) {
      children = 0;
    } else if (children > 5) {
      children = 5;
    }

    this.booking.totalMembers = members.toString();
    this.booking.childrens = children.toString();

    this.booking.price = this.basePrice * members + (this.basePrice * 0.5 * children);

    if (this.booking.price < 0) {
      this.booking.price = 0;
    }
  }

  submitBooking(bookingForm: NgForm) {
    if (bookingForm.invalid) {
      alert('Please fill all required fields correctly before submitting.');
      return;
    }

    const totalMembers = Number(this.booking.totalMembers);
    const children = Number(this.booking.childrens);
    const totalParticipants = totalMembers + children;
    const minRequired = this.maxMembers - 5;

    if (isNaN(totalMembers) || isNaN(children)) {
      alert('Please enter valid numbers for members and children.');
      return;
    }

    if (totalParticipants < minRequired || totalParticipants > this.maxMembers) {
      alert(`Total participants (members + children) must be between ${minRequired} and ${this.maxMembers}.`);
      return;
    }

    this.packagebookingservice.addBooking(this.booking, this.userId, this.packageId)
      .subscribe((response: any) => {
        if (response) {
          alert('Booking Successful! Proceed to payment.');
          this.router.navigate(['/paymenturl'], {
            queryParams: {
              amount: this.booking.price,
              userId: this.userId,
              bookingId: response.bookingId,
              roomId: this.roomId,
              roomPrice: this.roomPrice
            }
          });
        }
      });
  }

  toggleDropdown() {
    this.isDropdownOpen = !this.isDropdownOpen;
  }

  closeDropdown() {
    this.isDropdownOpen = false;
  }
}
