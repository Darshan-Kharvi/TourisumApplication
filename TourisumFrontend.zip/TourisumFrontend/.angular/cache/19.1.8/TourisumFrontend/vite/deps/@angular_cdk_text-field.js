import {
  AutofillMonitor,
  CdkAutofill,
  CdkTextareaAutosize,
  TextFieldModule
} from "./chunk-5SOOR5JX.js";
import "./chunk-Y534KWYI.js";
import "./chunk-LX77SFBY.js";
import "./chunk-74GEQGN4.js";
export {
  AutofillMonitor,
  CdkAutofill,
  CdkTextareaAutosize,
  TextFieldModule
};
