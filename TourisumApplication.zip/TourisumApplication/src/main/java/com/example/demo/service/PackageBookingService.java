package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import com.example.demo.entity.PackageBooking;
import com.example.demo.entity.Payment;

public interface PackageBookingService {
    List<PackageBooking> getAllBookings();
    List<PackageBooking> getBookingById(int bookingId);//get booking by user id 
    PackageBooking createBooking(int userId, long packageId, PackageBooking booking);
    PackageBooking updateBooking(Long id, PackageBooking bookingDetails);
    List<PackageBooking> deleteBooking(Long id);
    PackageBooking getPackageBookingById(long packageId);
	String updatePackageBookingStatus(long bookingId);
	String cancelPackageBooking(long bookingId);
}

