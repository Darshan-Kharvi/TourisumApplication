package com.example.demo.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async; 
import org.springframework.stereotype.Service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;

@Service
public class EmailService {

	@Autowired
	private JavaMailSender javaMailSender;
	
	@Async
	public void sendEmail(String toEmail,String subject,String message) {
		
		/*SimpleMailMessage mailMessage=new SimpleMailMessage();
		 mailMessage.setTo(toEmail);
		 mailMessage.setSubject(subject);
		 mailMessage.setText(message);
		 mailMessage.setFrom("darshukharvi00@gmail.com");
		 javaMailSender.send(mailMessage);*/
		
		MimeMessage mail = javaMailSender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(mail, "utf-8");
		//String htmlMsg = "<h3>Hello World!</h3> <br> <br> 
		//Regards,<br>Email Service";
		try {
		helper.setText(message, true); 
		helper.setTo(toEmail);
		helper.setSubject(subject);
		//helper.setFrom("pavikp4@gmail.com");
		helper.setFrom("darshukharvi00@gmail.com");
		javaMailSender.send(mail);
		}catch(MessagingException ex)
		{
			ex.printStackTrace();
		}
		}
}
