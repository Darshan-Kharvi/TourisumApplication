package com.example.demo.entity;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;




@Entity
public class Bankserver {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	@Column(unique = true)
	
	private String cCardnumber;
	@Column(unique = true,length = 50)
	
	private String cCvvnumber;
	@Column(unique = true,length = 50)
	
	private String cUpi;
	
	private String expiryDate ;
	
	private String cCardholdername;
	
//	public Bankserver() {
//		super();
//		// TODO Auto-generated constructor stub
//	}
//
//	public Bankserver(Long cCardnumber, Integer cCvvnumber, String cUpi, Date expiryDate) {
//		super();
//		this.cCardnumber = cCardnumber;
//		this.cCvvnumber = cCvvnumber;
//		this.cUpi = cUpi;
//		this.expiryDate = expiryDate;
//	}
	
	

	public Integer getId() {
		return id;
	}

	public String getcCardholdername() {
		return cCardholdername;
	}

	public void setcCardholdername(String cCardholdername) {
		this.cCardholdername = cCardholdername;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	
	public String getcCardnumber() {
		return cCardnumber;
	}

	public void setcCardnumber(String cCardnumber) {
		this.cCardnumber = cCardnumber;
	}

	public String getcCvvnumber() {
		return cCvvnumber;
	}

	public void setcCvvnumber(String cCvvnumber) {
		this.cCvvnumber = cCvvnumber;
	}

	public String getcUpi() {
		return cUpi;
	}

	public void setcUpi(String cUpi) {
		this.cUpi = cUpi;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	@Override
	public String toString() {
		return "Bankserver [id=" + id + ", cCardnumber=" + cCardnumber + ", cCvvnumber=" + cCvvnumber + ", cUpi=" + cUpi
				+ ", expiryDate=" + expiryDate + ", cCardholdername=" + cCardholdername + "]";
	}

	


	

	
}