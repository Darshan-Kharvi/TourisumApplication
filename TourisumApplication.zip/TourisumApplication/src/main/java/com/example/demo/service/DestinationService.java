package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import com.example.demo.entity.Destination;

public interface DestinationService {
	List<Destination> getAllDestination();
	Optional<Destination> getDestinationById(Long id);
	Destination createDestination(Destination destination);
	Destination updateDestination(Long id, Destination destinationDetails);
	List<Destination> deleteDestination(Long id);
}
