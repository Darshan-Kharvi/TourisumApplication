package com.example.demo.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Destination;
import com.example.demo.entity.Enquiry;
import com.example.demo.entity.User;
import com.example.demo.repository.EnquiryRepository;
import com.example.demo.service.DestinationService;
import com.example.demo.service.EnquiryService;
import com.example.demo.service.UserService;

@Service
public class EnquiryServiceImpl implements EnquiryService {

	@Autowired
	private UserService userService;
	
	@Autowired
	private DestinationService destinationService;
	
	@Autowired
	private EnquiryRepository enquiryRepository;
	
	@Autowired
   	private EmailService emailService;
	
	@Override
	public List<Enquiry> getAllEnquirys() {
		return enquiryRepository.findAll();
	}

	@Override
	public List<Enquiry> getEnquiryById(int id) {
		return enquiryRepository.findByUserUserId(id);
	}

//	@Override
//	public Enquiry createEnquiry(int userId, long destinationId, Enquiry enquiry) {
//		User user=userService.getUserById(userId).get();
//		Destination destination=destinationService.getDestinationById(destinationId).get();
//		enquiry.setUser(user);
//		enquiry.setDestination(destination);
//		return enquiryRepository.save(enquiry);
//	}
	
	@Override
	public Enquiry createEnquiry(int userId, long destinationId, Enquiry enquiry) {
	    User user = userService.getUserById(userId).orElse(null);
	    Destination destination = destinationService.getDestinationById(destinationId).orElse(null);

	    if (user != null && destination != null) {
	        enquiry.setUser(user);
	        enquiry.setDestination(destination);
	        Enquiry savedEnquiry = enquiryRepository.save(enquiry);

	        // Send confirmation email to user
	        String message = "Hi <b>" + user.getFirstName() + " " + user.getLastName() + "</b>,<br>" +
	                         "Thank you for your enquiry about <b>" + destination.getDestinationName() + "</b>.<br>" +
	                         "Our team will get back to you shortly with more details.<br><br>" +
	                         "Regards,<br>LastDestinationTripPlanner Team.";
	        String subject = "Enquiry Received";

	        emailService.sendEmail(user.getAccountEmail(), subject, message);

	        return savedEnquiry;
	    }

	    return null;
	}


	@Override
	public List<Enquiry> deleteEnquiry(Long id) {
		enquiryRepository.deleteById(id);
		return enquiryRepository.findAll();
	}

}
