package com.example.demo.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

@Entity
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer userId;
	@NotBlank(message = "Please Enter Your FirstName")
	private String firstName;
	private String lastName;
	@Column(length=50,nullable=false,unique = true)
	@Email(message="Please enter valid email",regexp = "^[a-zA-Z0-9._-]+@[a-zA-Z0-9-]+\\.[a-zA-Z.]{2,5}")
	private String accountEmail;
	@Column(unique = true)
	private String phoneNo;
	private String address;
   //private String membership;
	@Size(min=4, message="Password Should Contain Atleast 4 characters")
	@Size(max=15,message="")
	private String password;
	//@Temporal(TemporalType.DATE)
	//private Date accountCreatedDate=new Date();
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getAccountEmail() {
		return accountEmail;
	}
	public void setAccountEmail(String accountEmail) {
		this.accountEmail = accountEmail;
	}

	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	/*
	 * public String getMembership() { return membership; } public void
	 * setMembership(String membership) { this.membership = membership; }
	 */
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	/*
	 * public Date getAccountCreatedDate() { return accountCreatedDate; } public
	 * void setAccountCreatedDate(Date accountCreatedDate) { this.accountCreatedDate
	 * = accountCreatedDate; }
	 */
	
}
