package com.example.demo.serviceimpl;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Payment;
import com.example.demo.entity.Room;
import com.example.demo.entity.User;
import com.example.demo.repository.PaymentRepository;
import com.example.demo.repository.RoomRepository;
import com.example.demo.service.PackageBookingService;
import com.example.demo.service.PackageService;
import com.example.demo.service.PaymentService;
import com.example.demo.service.RoomService;
import com.example.demo.service.UserService;

import java.util.List;
import java.util.Optional;

@Service
public class PaymentServiceImpl implements PaymentService {

	@Autowired
	private UserService userService;
	
	@Autowired
	private PackageBookingService packageBookingService;
	
    @Autowired
    private PaymentRepository paymentRepository;
    
    @Autowired
    private RoomService roomService;

    public List<Payment> getAllPayments() {
        return paymentRepository.findAll();
    }

    public List<Payment> getPaymentById(int id) {
        return paymentRepository.findByUserUserId(id);
    }

    public Payment createPayment(int userId, long bookingId,long roomId,double roomPrice, Payment payment) {
    	User user = userService.getUserById(userId).get();
    	com.example.demo.entity.PackageBooking booking=null;
    	if(roomId==0) {
    	 booking = packageBookingService.getPackageBookingById(bookingId);
    	}else {
    		Room room = roomService.getRoomById(roomId).get();
    		payment.setRoom(room);
    		payment.setPaymentAmount(roomPrice);
    	}
    	payment.setUser(user);
    	payment.setBooking(booking);
        return paymentRepository.save(payment);
    }

    public Payment updatePayment(Long id, Payment paymentDetails) {
        return paymentRepository.findById(id).map(payment -> {
            payment.setUser(paymentDetails.getUser());
            payment.setBooking(paymentDetails.getBooking());
            payment.setPaymentDate(paymentDetails.getPaymentDate());
            payment.setPaymentAmount(paymentDetails.getPaymentAmount());
            payment.setPaymentStatus(paymentDetails.getPaymentStatus());
            return paymentRepository.save(payment);
        }).orElseThrow(() -> new RuntimeException("Payment not found with id " + id));
    }

    public void deletePayment(Long id) {
        paymentRepository.deleteById(id);
    }

	@Override
	public List<Payment> getAllRoomPayments() {
		return paymentRepository.getAllRoomPayments();
	}

	@Override
	public List<Payment> getAllPackagePayments() {
		return paymentRepository.getAllPackagePayments();
	}

	

}
