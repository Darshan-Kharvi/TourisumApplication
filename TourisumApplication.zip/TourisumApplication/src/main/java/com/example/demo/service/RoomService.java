package com.example.demo.service;
import java.util.List;
import java.util.Optional;

import com.example.demo.entity.Room;



public interface RoomService {
    List<Room> getAllRoom();
    Optional<Room> getRoomById(Long id);
    Room createRoom(Room room);
    Room updateRoom(Long id, Room roomDetails);
    List<Room> deleteRoom(Long id);
}

