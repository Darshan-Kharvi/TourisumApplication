package com.example.demo.serviceimpl;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.entity.Destination;
import com.example.demo.repository.DestinationRepository;
import com.example.demo.service.DestinationService;

@Service
public class DestinationServiceImpl implements DestinationService{
	  
	@Autowired
	private DestinationRepository destinationRepository;

	@Override
	public List<Destination> getAllDestination() {
		return destinationRepository.findAll();
	}

	@Override
	public Optional<Destination> getDestinationById(Long id) {
		return destinationRepository.findById(id);
	}

	@Override
	public Destination createDestination(Destination destination) {
		return destinationRepository.save(destination);
	}

	@Override
	public Destination updateDestination(Long id, Destination destDetails){
		return destinationRepository.findById(id).map(dest->{
			dest.setDestinationName(destDetails.getDestinationName());
			dest.setDestinationLocation(destDetails.getDestinationLocation());
			dest.setDescription(destDetails.getDescription());
			dest.setImage(destDetails.getImage());
			return destinationRepository.save(dest);
		}).orElseThrow(() -> new RuntimeException("Destination not found with id " + id));
	}

	@Override
	public List<Destination> deleteDestination(Long id) {
		destinationRepository.deleteById(id);
		return destinationRepository.findAll();
	}
	
	

}
