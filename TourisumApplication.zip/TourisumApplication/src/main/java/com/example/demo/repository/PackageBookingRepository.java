package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.PackageBooking;

import jakarta.transaction.Transactional;

import java.util.List;
import java.util.Date;

@Repository
public interface PackageBookingRepository extends JpaRepository<PackageBooking, Long> {
	
	 public List<PackageBooking> findByUserUserId(int userId);

    // Find bookings by user ID
	/*
	 * List<PackageBooking> findByUserUserId(Integer userId);
	 * 
	 * @Query("SELECT b FROM Booking b WHERE b.user.userId = :userId")
	 * List<PackageBooking> getBookingsByUserId(@Param("userId") Integer userId);
	 * 
	 * // Find bookings by tour ID List<PackageBooking> findByTourId(Long tourId);
	 * 
	 * @Query("SELECT b FROM Booking b WHERE b.tourId = :tourId")
	 * List<PackageBooking> getBookingsByTourId(@Param("tourId") Long tourId);
	 * 
	 * // Find bookings by status (e.g., "CONFIRMED", "CANCELLED")
	 * List<PackageBooking> findByStatus(String status);
	 * 
	 * @Query("SELECT b FROM Booking b WHERE b.status = :status")
	 * List<PackageBooking> getBookingsByStatus(@Param("status") String status);
	 * 
	 * // Get confirmed bookings
	 * 
	 * @Query("SELECT b FROM Booking b WHERE b.status = 'CONFIRMED'")
	 * List<PackageBooking> getConfirmedBookings();
	 * .
	 * // Get canceled bookings
	 * 
	 * @Query("SELECT b FROM Booking b WHERE b.status = 'CANCELLED'")
	 * List<PackageBooking> getCancelledBookings();
	 * 
	 * // Find bookings made after a specific date
	 * 
	 * @Query("SELECT b FROM Booking b WHERE b.bookingDate > :date")
	 * List<PackageBooking> findBookingsAfterDate(@Param("date") Date date);
	 * 
	 * // Find bookings within a date range
	 * 
	 * @Query("SELECT b FROM Booking b WHERE b.bookingDate BETWEEN :startDate AND :endDate"
	 * ) List<PackageBooking> findBookingsBetweenDates(@Param("startDate") Date
	 * startDate, @Param("endDate") Date endDate);
	 * 
	 * // Find the total number of bookings for a specific tour
	 * 
	 * @Query("SELECT COUNT(b) FROM Booking b WHERE b.tourId = :tourId") long
	 * countBookingsForTour(@Param("tourId") Long tourId);
	 */
	 
	 @Transactional
	 @Modifying
	 @Query(value="update bookings b set b.status='BOOKED' where b.booking_id=?1",nativeQuery=true)
		public int updatePackageBookingStatus(long bookingId);
	 
	 @Transactional
	 @Modifying
	 @Query(value="update bookings b set b.status='CANCELED' where b.booking_id=?1",nativeQuery=true)
		public int cancelPackageBooking(long bookingId);
	 
}
