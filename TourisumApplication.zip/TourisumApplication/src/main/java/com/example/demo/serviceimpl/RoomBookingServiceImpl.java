package com.example.demo.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.PackageBooking;
import com.example.demo.entity.Room;
import com.example.demo.entity.RoomBooking;
import com.example.demo.entity.User;
import com.example.demo.repository.PackageBookingRepository;
import com.example.demo.repository.RoomBookingRepository;
import com.example.demo.service.PackageService;
import com.example.demo.service.RoomBookingService;
import com.example.demo.service.RoomService;
import com.example.demo.service.UserService;

@Service
public class RoomBookingServiceImpl implements RoomBookingService {

	
	@Autowired
	private UserService userService;
	
	@Autowired
	private RoomService roomService;

    @Autowired
    private RoomBookingRepository roombookingRepository;
    
    @Autowired
	private EmailService emailService;


    public List<RoomBooking> getAllBookings() {
        return roombookingRepository.findAll();
    }

    public List<RoomBooking> getBookingById(int id) {
        return roombookingRepository.findByUserUserId(id);
    }

    public RoomBooking createBooking(int userId, long roomId, RoomBooking booking) {
    	RoomBooking roomBooking=roombookingRepository.findByUserUserIdAndRoomRoomIdAndCheckinDateAndCheckoutDate( userId, roomId, booking.getCheckinDate(),booking.getCheckoutDate());
    	if(roomBooking==null) {
    	User user = userService.getUserById(userId).get();
    	 com.example.demo.entity.Room room = roomService.getRoomById(roomId).get();
    	booking.setUser(user);
    	booking.setRoom(room);
        return roombookingRepository.save(booking);
    	}else {
    		return null;
    	}
    }

    public RoomBooking updateBooking(Long id, RoomBooking bookingDetails) {
        return roombookingRepository.findById(id).map(booking -> {
            booking.setUser(bookingDetails.getUser());
            booking.setCheckinDate(booking.getCheckinDate());
            booking.setCheckoutDate(booking.getCheckoutDate());
            booking.setStatus(bookingDetails.getStatus());
            return roombookingRepository.save(booking);
        	}).orElseThrow(() -> new RuntimeException("Booking not found with id " + id));
    }

    public List<RoomBooking> deleteBooking(Long id) {
       roombookingRepository.deleteById(id);
       return roombookingRepository.findAll();
    }

//	@Override
//	public String updateRoomBookingStatus(long roomId) {
//		int res= roombookingRepository.updateRoomBookingStatus(roomId);
//		if(res>0) {
//			return "Booking Updated SucessFully";
//		}else {
//			return "Problem in Updating";
//		}
//	}

    @Override
    public String updateRoomBookingStatus(long roomId) {
        int res = roombookingRepository.updateRoomBookingStatus(roomId);
        
        if (res > 0) {
            // Fetch user details based on roomId
            RoomBooking booking = roombookingRepository.findById(roomId).orElse(null);
            if (booking != null && booking.getUser() != null) {
                User user = booking.getUser();
                String message = "Hi <b>" + user.getFirstName() + " " + user.getLastName() + "</b>,<br>" +
                                 "Congratulations! Your booking (Room ID: " + roomId + ") has been successfully Booked in our LastDestinationTripPlanner Application.";
                String subject = "Booking Status Updated";
                emailService.sendEmail(user.getAccountEmail(), subject, message);
            }

            return "Booking Updated Successfully";
        } else {
            return "Problem in Updating";
        }
    }

    
	@Override
	public String cancelRoomBooking(long bookingId) {
		int res= roombookingRepository.cancelRoomBooking(bookingId);
		if(res>0) {
			return "Booking Updated SucessFully";
		}else {
			return "Problem in Updating";
		}
	}

 
}
