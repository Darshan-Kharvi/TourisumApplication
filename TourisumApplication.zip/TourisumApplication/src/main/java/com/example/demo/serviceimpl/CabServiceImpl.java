package com.example.demo.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Cab;
import com.example.demo.repository.CabRepository;
import com.example.demo.service.CabService;

@Service
public class CabServiceImpl implements CabService{

	@Autowired
	private CabRepository cabRepository;
	
	@Override
	public List<Cab> getAllCab() {
		return cabRepository.findAll();
	}

	@Override
	public Optional<Cab> getCabById(Long id) {
		return cabRepository.findById(id); 
	}

	@Override
	public Cab createCab(Cab cab) {
		return cabRepository.save(cab);
	}

	@Override
	public Cab updateCab(Long id, Cab CabDetails) {
		return cabRepository.findById(id).map(cab->{
			cab.setCabName(CabDetails.getCabName());
			cab.setCabtype(CabDetails.getCabtype());
			cab.setImage(CabDetails.getImage());
			cab.setPrice(CabDetails.getPrice());
			cab.setDriverName(CabDetails.getDriverName());
			cab.setDriverNo(CabDetails.getDriverNo());
			cab.setVehicleNo(CabDetails.getVehicleNo());
			return cabRepository.save(cab);
		}).orElseThrow(() -> new RuntimeException("Cab not found with id " + id));
			
	}

	@Override
	public List<Cab> deleteCab(Long id) {
		cabRepository.deleteById(id);
		return cabRepository.findAll();
	}

}
