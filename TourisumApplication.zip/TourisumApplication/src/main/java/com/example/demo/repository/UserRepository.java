package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.example.demo.entity.User;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {

    // Find user by email
    Optional<User> findByAccountEmail(String accountEmail);
   
    
   // @Query(value = "select * from user a where (a.account_email=?1 or a.account_phone=? )",nativeQuery = true)
    //public User findByAccountEmail(String accountMail);
    
    @Query(value ="select * from user a where (a.account_email= ?1 or a.phone_no= ?1) && a.password = ?2",nativeQuery = true)
	public  User findbyusername(String accountMail, String accountPasswords);

    // Find user by phone number
    Optional<User> findByPhoneNo(String phoneNo);

//    @Query("SELECT u FROM User u WHERE u.PhoneNo = :phoneNo")
//    Optional<User> findUserByPhoneNo(@Param("phoneNo") String phoneNo);

    
    @Query(value = "select * from user a where a.account_email= ?1",nativeQuery = true)
   	public User findByEmail(String usermail);
    
}
