package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Enquiry;
import com.example.demo.entity.PackageBooking;
import com.example.demo.service.EnquiryService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/api/enquirys")
public class EnquiryController {
	
	@Autowired
	private EnquiryService enquiryService;
	
    @GetMapping
    public List<Enquiry> getAllEnquirys() {
        return enquiryService.getAllEnquirys();
    }
    
    @GetMapping("/user/{userId}")
    public List<Enquiry> getEnquiryById(@PathVariable("userId") int id) {
        return enquiryService.getEnquiryById(id);
    }
    
    @PostMapping("/{userId}/{destinationId}")
    public Enquiry createEnquiry(@PathVariable("userId") int userId,@PathVariable("destinationId") long destinationId,@RequestBody Enquiry enquiry) {
        return enquiryService.createEnquiry(userId, destinationId, enquiry);
    }
    

    @DeleteMapping("/{id}")
    public List<Enquiry> deleteEnquiry(@PathVariable Long id) {
       return enquiryService.deleteEnquiry(id);
    }
    
    }
