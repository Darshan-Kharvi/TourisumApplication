package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import com.example.demo.entity.Package;



public interface PackageService {
    List<Package> getAllPackage();
    Optional<Package> getPackageById(Long id);
    Package createPackage(Package tour);
    Package updatePackage(Long id, Package tourDetails);
    List<Package> deletePackage(Long id);
}
