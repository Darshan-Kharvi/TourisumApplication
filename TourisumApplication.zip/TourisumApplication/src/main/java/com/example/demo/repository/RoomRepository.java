package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Room;

import java.util.List;

@Repository
public interface RoomRepository extends JpaRepository<Room, Long> {
//	
//	// Custom query to find destinations by name (case-insensitive)
//	@Query("SELECT d FROM ROOM d WHERE LOWER(d.Name) LIKE LOWER(CONCAT('%', :destinationName, '%'))")
//	List<Room> searchDestinationsByName(@Param("destinationName") String destinationName);
//
//	// Custom query to find destinations by location (case-insensitive)
//	@Query("SELECT d FROM ROOM d WHERE LOWER(d.location) LIKE LOWER(CONCAT('%', :location, '%'))")
//	List<Room> searchDestinationsByLocation(@Param("location") String location);
//
//
//    // Custom query to get destinations by a specific location
//    @Query("SELECT d FROM Destination d WHERE d.location = :location")
//    List<Room> getDestinationsByLocation(@Param("location") String location);
//
//    // Get all destinations sorted by name
//    @Query("SELECT d FROM Destination d ORDER BY d.destinationName ASC")
//    List<Room> getAllDestinationsSortedByName();
//
//    // Count the total number of destinations
//    @Query("SELECT COUNT(d) FROM Destination d")
//    long countTotalDestinations();
}

