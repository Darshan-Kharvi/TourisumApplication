package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.PackageBooking;
import com.example.demo.service.PackageBookingService;

import java.util.List;
import java.util.Optional;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PathVariable;


@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/api/packagebookings")
public class PackageBookingController {

    @Autowired
    private PackageBookingService bookingService;

    @GetMapping
    public List<PackageBooking> getAllBookings() {
        return bookingService.getAllBookings();
    }

    @GetMapping("/user/{userId}")
    public List<PackageBooking> getBookingById(@PathVariable("userId") int id) {
        return bookingService.getBookingById(id);
    }

    @PostMapping("/{userId}/{packageId}")
    public PackageBooking createBooking(@PathVariable("userId") int userId,@PathVariable("packageId") long packageId,@RequestBody PackageBooking booking) {
        return bookingService.createBooking(userId,packageId,booking);
    }

    @PutMapping("/{id}")
    public PackageBooking updateBooking(@PathVariable Long id, @RequestBody PackageBooking booking) {
        return bookingService.updateBooking(id, booking);
    }

    @DeleteMapping("/{id}")
    public List<PackageBooking> deleteBooking(@PathVariable Long id) {
       return bookingService.deleteBooking(id);
    }
    
    @PutMapping("/statusupdate/{bookingid}")
    public  String updatePackageBookingStatus(@PathVariable long bookingid, @RequestBody PackageBooking booking) {
      return bookingService.updatePackageBookingStatus(bookingid);
       
    }
    
//    @PutMapping("/cancel/{bookingid}")
//    public  String cancelPackageBooking(@PathVariable long bookingid, @RequestBody PackageBooking booking) {
//      return bookingService.cancelPackageBooking(bookingid);
//       
//    }
    
    @PutMapping("/cancel/{bookingid}")
    public  String cancelPackageBooking(@PathVariable long bookingid) {
      return bookingService.cancelPackageBooking(bookingid);
       
    }
    
}
