package com.example.demo.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.PackageBooking;
import com.example.demo.entity.Payment;
import com.example.demo.service.PaymentService;

import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/api/payments")
public class PaymentController {

    @Autowired
    private PaymentService paymentService;

    @GetMapping
    public List<Payment> getAllPayments() {
        return paymentService.getAllPayments();
    }

    @GetMapping("/user/{userId}")
    public List<Payment> getPaymentById(@PathVariable("userId") int id) {
        return (List<Payment>) paymentService.getPaymentById(id);
    }

    @PostMapping("/{userId}/{bookingId}/{roomId}/{roomPrice}")
    public Payment createPayment(@PathVariable("userId") int userId,@PathVariable("bookingId") long bookingId,@PathVariable("roomId") long roomId,@PathVariable("roomPrice") double roomPrice,@RequestBody Payment payment) {
    	System.out.println("payment"+payment);
    	System.out.println("user"+userId);
    	System.out.println("bookingid"+bookingId);
    	System.out.println("roomid"+roomId);
    	System.out.println("price"+roomPrice);
    	
        return paymentService.createPayment(userId,bookingId,roomId,roomPrice,payment);
    }

    @PutMapping("/{id}")
    public Payment updatePayment(@PathVariable Long id, @RequestBody Payment payment) {
        return paymentService.updatePayment(id, payment);
    }

    @DeleteMapping("/{id}")
    public void deletePayment(@PathVariable Long id) {
        paymentService.deletePayment(id);
    }
    
    @GetMapping("/getallpaymentsbyroom")
    public List<Payment> getAllRoomPayments(){
    	return paymentService.getAllRoomPayments();
    }
    
    @GetMapping("/getallpaymentsbypackage")
    public List<Payment> getAllPackagePayments(){
    	return paymentService.getAllPackagePayments();
    }
    
}

