package com.example.demo.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.PackageBooking;
import com.example.demo.entity.User;
import com.example.demo.repository.PackageBookingRepository;
import com.example.demo.service.PackageBookingService;
import com.example.demo.service.PackageService;
import com.example.demo.service.UserService;

import java.util.List;
import java.util.Optional;

@Service
public class PackageBookingServiceImpl implements PackageBookingService {
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private PackageService packageService;

    @Autowired
    private PackageBookingRepository bookingRepository;
    
    @Autowired
   	private EmailService emailService;

    public List<PackageBooking> getAllBookings() {
        return bookingRepository.findAll();
    }

    public List<PackageBooking> getBookingById(int id) {
        return bookingRepository.findByUserUserId(id);
    }

    public PackageBooking createBooking(int userId, long packageId, PackageBooking booking) {
    	User user = userService.getUserById(userId).get();
    	com.example.demo.entity.Package package1 = packageService.getPackageById(packageId).get();
    	booking.setUser(user);
    	booking.setPackage1(package1);
        return bookingRepository.save(booking);
    }

    public PackageBooking updateBooking(Long id, PackageBooking bookingDetails) {
        return bookingRepository.findById(id).map(booking -> {
            booking.setUser(bookingDetails.getUser());
            booking.setBookingDate(booking.getBookingDate());
            booking.setPicupLocation(bookingDetails.getPicupLocation());
            booking.setStatus(bookingDetails.getStatus());
            
            
            return bookingRepository.save(booking);
        }).orElseThrow(() -> new RuntimeException("Booking not found with id " + id));
    }

    public List<PackageBooking> deleteBooking(Long id) {
        bookingRepository.deleteById(id);
        return bookingRepository.findAll();
    }

	@Override
	public PackageBooking getPackageBookingById(long packageId) {
		// TODO Auto-generated method stub
		return bookingRepository.findById(packageId).get();
	}

//	@Override
//	public String updatePackageBookingStatus(long bookingId) {
//		// TODO Auto-generated method stub
//		int res= bookingRepository.updatePackageBookingStatus(bookingId);
//		if(res>0) {
//			return "Booking Updated SucessFully";
//		}else {
//			return "Problem in Updating";
//		}
//	}
	
	
	@Override
	public String updatePackageBookingStatus(long bookingId) {
	    int res = bookingRepository.updatePackageBookingStatus(bookingId);

	    if (res > 0) {
	        // Fetch package booking and user details
	        PackageBooking booking = bookingRepository.findById(bookingId).orElse(null);
	        if (booking != null && booking.getUser() != null) {
	            User user = booking.getUser();
	            String message = "Hi <b>" + user.getFirstName() + " " + user.getLastName() + "</b>,<br>" +
	                             "Congratulations! Your tour package booking (Booking ID: " + bookingId + ") has been successfully confirmed in our LastDestinationTripPlanner Application.";
	            String subject = "Package Booking Status Updated";
	            emailService.sendEmail(user.getAccountEmail(), subject, message);
	        }

	        return "Booking Updated Successfully";
	    } else {
	        return "Problem in Updating";
	    }
	}


	@Override
	public String cancelPackageBooking(long bookingId) {
		int res= bookingRepository.cancelPackageBooking(bookingId);
		if(res>0) {
			return "Booking canceld SucessFully";
		}else {
			return "Problem in Updating";
		}
		
	}


	

}

