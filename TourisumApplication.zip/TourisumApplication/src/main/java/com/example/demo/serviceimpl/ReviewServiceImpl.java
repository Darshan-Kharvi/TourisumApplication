package com.example.demo.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Review;
import com.example.demo.entity.User;
import com.example.demo.repository.ReviewRepository;
import com.example.demo.service.ReviewService;
import com.example.demo.service.UserService;


@Service
public class ReviewServiceImpl implements ReviewService {
	
	@Autowired
	 private ReviewRepository reviewRepository;
	
	@Autowired
	private UserService userService;
	

	@Override
	public List<Review> getAllReviews() {
		return reviewRepository.findAll();
	}

	@Override
	public Optional<Review> getReviewsById(Long id) {
		return reviewRepository.findById(id);
	}

	@Override
	public Review createReview(int userId,Review review) {
		User user = userService.getUserById(userId).get();
		review.setUser(user);
		return reviewRepository.save(review);
	}

	@Override
	public Review updateReview(Long id, Review reviewDetails) {
		return reviewRepository.findById(id).map(review->{
		review.setComments(reviewDetails.getComments());
		return reviewRepository.save(review);
		}).orElseThrow(() -> new RuntimeException("Room not found with id " + id));
	}

	@Override
	public List<Review> deleteReview(Long id) {
		reviewRepository.deleteById(id);
		return reviewRepository.findAll();
	}

	@Override
	public List<Review> getReviewsByUserId(Long userId) {
		return reviewRepository.findByUserUserId(userId);
	}

}
