package com.example.demo.service;

import java.util.List;
import java.util.Optional;
import com.example.demo.entity.RoomBooking;

public interface RoomBookingService {
	    List<RoomBooking> getAllBookings();
	    List<RoomBooking> getBookingById(int id);
	    RoomBooking createBooking(int userId, long roomId, RoomBooking booking);
	    RoomBooking updateBooking(Long id, RoomBooking bookingDetails);
	    List<RoomBooking> deleteBooking(Long id);
	    String updateRoomBookingStatus(long roomId);
	    String cancelRoomBooking(long bookingId);
	    
}
