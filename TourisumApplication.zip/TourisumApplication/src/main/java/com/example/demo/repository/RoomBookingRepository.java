package com.example.demo.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.RoomBooking;

import jakarta.transaction.Transactional;

@Repository
public interface RoomBookingRepository extends JpaRepository<RoomBooking, Long> {
	
	public List<RoomBooking> findByUserUserId(int userId);


	 @Transactional
	 @Modifying
	 @Query(value="update roombookings b set b.status='BOOKED' where b.booking_id=?1",nativeQuery=true)
		public int updateRoomBookingStatus(long roomId);
	 
//	 @Transactional
//	 @Modifying
//	 @Query(value="UPDATE roombookings b SET b.status = 'CANCELED', b.checkin_date = NULL, b.checkout_date = NULL WHERE b.booking_id = ?1",nativeQuery=true)
//		public int cancelRoomBooking(long bookingId);
	 
	 @Transactional
	 @Modifying
	 @Query(value="UPDATE roombookings b SET b.status = 'CANCELED', b.checkin_date = CURRENT_TIMESTAMP, b.checkout_date = CURRENT_TIMESTAMP WHERE b.booking_id = ?1",nativeQuery=true)
		public int cancelRoomBooking(long bookingId);

	 public RoomBooking findByUserUserIdAndRoomRoomIdAndCheckinDateAndCheckoutDate(int userId, long roomId, Date checkinDate, Date checkoutDate);
	
}
