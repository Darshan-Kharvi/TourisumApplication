package com.example.demo.serviceimpl;


import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;
import com.example.demo.service.UserService;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;
    
    @Autowired
	private EmailService emailService;

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public Optional<User> getUserById(Integer id) {
        return userRepository.findById(id);
    }
    @Override
	public User findbyusername(String accountMail, String accountPasswords) 
	{
		return userRepository.findbyusername(accountMail, accountPasswords);
		
	}

	/*
	 * public Optional<User> getUserByEmail(String email) { return
	 * userRepository.findBy.AccountEmail(email); }
	 */

    public User createUser(User user) {
    	String message="Hi <b>"+user.getFirstName()+" "+user.getLastName()+"</b>,<br>Congratulations You have registered Your "
				+ "Account "+user.getAccountEmail()+" in Our LastDestinationTripPlanner Application ";
		String subject="Account Creation";
		emailService.sendEmail(user.getAccountEmail(), subject, message);

        return userRepository.save(user);
    }

    public User updateUser(Integer id, User userDetails) {
        return userRepository.findById(id).map(user -> {
            user.setFirstName(userDetails.getFirstName());
            user.setLastName(userDetails.getLastName());
            user.setAccountEmail(userDetails.getAccountEmail());
            user.setPhoneNo(userDetails.getPhoneNo());
            user.setAddress(userDetails.getAddress());
         //   user.setMembership(userDetails.getMembership());
            user.setPassword(userDetails.getPassword());
            return userRepository.save(user);
        }).orElseThrow(() -> new RuntimeException("User not found with id " + id));
    }

    public List<User> deleteUser(Integer id) {
        userRepository.deleteById(id);
        return userRepository.findAll();
    }

	@Override
	public User forgotpass(String accountMail, String npass) {
		// TODO Auto-generated method stub
		User oldUser = userRepository.findByAccountEmail(accountMail).orElseThrow(() -> new RuntimeException());
		oldUser.setPassword(npass);
		return userRepository.save(oldUser);
	}

	@Override
	public User findByUserEmailId(String accountEmail) {
		// TODO Auto-generated method stub
		return userRepository.findByAccountEmail(accountEmail).get();
	}

	@Override
	public User findByEmail(String useremail) 
	{
		return userRepository.findByEmail(useremail);
	}




	
}
