package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Bankserver;



@Repository
public interface BankserverRepositry  extends JpaRepository<Bankserver, Integer>{

//	
	@Query(value = "SELECT * FROM bankserver b WHERE b.c_cardnumber = ?1 AND b.c_cvvnumber = ?2 AND b.expiry_Date LIKE CONCAT(?3, '%')", nativeQuery = true)
	public Bankserver findByCardCvv(Long cCardnumber, Integer cCvvnumber, String expiryDate);

	@Query(value = "select * from bankserver b where b.c_upi=?1",nativeQuery = true)
	public Bankserver findByUpi(String cUpi);
	
	@Query(value = "SELECT * FROM bankserver b WHERE b.c_cardnumber = ?1 AND b.c_cvvnumber = ?2 AND b.expiry_Date =?3 AND b.c_cardholdername=?4", nativeQuery = true)
	public Bankserver cardValidation(String cCardnumber, String cCvvnumber, String expiryDate, String cCardholdername);


}