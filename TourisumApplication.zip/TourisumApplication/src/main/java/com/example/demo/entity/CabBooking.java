package com.example.demo.entity;

import java.util.Date;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "cabbookings")
public class CabBooking {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "booking_id")
    private Long bookingId;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "user_id")
    private User user;
    
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "cab_id")
    private Cab cab;

    @Column(name = "booking_date")
    private Date bookingDate;
    
    @Column(name="total_members")
    private Integer totalMembers;
    
    @Column(name="childrens")
    private Integer childrens;
    
    @Column(name = "status",length = 50)
    private String status;
    
    @Column(name="price",length = 50)
    private String price;
    
    @Column(name="cab_type",length = 50)
    private String cabType;
    
    @Column(name="picuplocation",length = 50)
    private String picuplocation;
    
    @Column(name="droplocation",length = 50)
    private String droplocation;
    
    @Column(name="totaldays",length = 50)
    private String totaldays;
    
    @Column(name="totaldistance",length = 50)
    private String totaldistance;
    
    
    public Long getBookingId() {
		return bookingId;
	}

	public void setBookingId(Long bookingId) {
		this.bookingId = bookingId;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Cab getCab() {
		return cab;
	}

	public void setCab(Cab cab) {
		this.cab = cab;
	}

	public Date getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(Date bookingDate) {
		this.bookingDate = bookingDate;
	}

	public Integer getTotalMembers() {
		return totalMembers;
	}

	public void setTotalMembers(Integer totalMembers) {
		this.totalMembers = totalMembers;
	}

	public Integer getChildrens() {
		return childrens;
	}

	public void setChildrens(Integer childrens) {
		this.childrens = childrens;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getCabType() {
		return cabType;
	}

	public void setCabType(String cabType) {
		this.cabType = cabType;
	}

	public String getPicuplocation() {
		return picuplocation;
	}

	public void setPicuplocation(String picuplocation) {
		this.picuplocation = picuplocation;
	}

	public String getDroplocation() {
		return droplocation;
	}

	public void setDroplocation(String droplocation) {
		this.droplocation = droplocation;
	}

	public String getTotaldays() {
		return totaldays;
	}

	public void setTotaldays(String totaldays) {
		this.totaldays = totaldays;
	}

	public String getTotaldistance() {
		return totaldistance;
	}

	public void setTotaldistance(String totaldistance) {
		this.totaldistance = totaldistance;
	}

	

}
