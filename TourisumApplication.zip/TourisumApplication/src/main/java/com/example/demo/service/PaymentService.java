package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import com.example.demo.entity.Payment;



public interface PaymentService {
    List<Payment> getAllPayments();
    List<Payment> getPaymentById(int paymentid);
    Payment createPayment(int userId, long bookingId,long roomId,double roomPrice, Payment payment);
    Payment updatePayment(Long id, Payment paymentDetails);
    void deletePayment(Long id);
    List<Payment> getAllRoomPayments();
    List<Payment> getAllPackagePayments();
}

