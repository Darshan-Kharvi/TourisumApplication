package com.example.demo.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.PackageBooking;
import com.example.demo.entity.Payment;


@Repository
public interface PaymentRepository extends JpaRepository<Payment, Long> {
	
	 public List<Payment> findByUserUserId(int userId);
	 
	 @Query(value = "select * from payments where room_id is not null ",nativeQuery = true)
	 public List<Payment> getAllRoomPayments();
	 
	 @Query(value = " select *from payments where booking_id is not null ",nativeQuery = true)
	 public List<Payment> getAllPackagePayments();
	 
}

