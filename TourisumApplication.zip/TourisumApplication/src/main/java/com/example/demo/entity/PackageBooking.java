package com.example.demo.entity;

import java.util.Date;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "bookings")
	public class PackageBooking {

	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "booking_id")
	    private Long bookingId;

	    @ManyToOne(cascade = CascadeType.ALL)
	    @JoinColumn(name = "user_id")
	    private User user;
	    
	    @ManyToOne(cascade = CascadeType.ALL)
	    @JoinColumn(name = "package_id")
	    private Package package1;

	    @Column(name = "booking_date")
	    private Date bookingDate;
	    
	    
	    @Column(name="total_members",length = 50)
	    private String totalMembers;
	    
	    @Column(name="childrens",length = 50)
	    private String childrens;
	    
	    
	    @Column(name="picupLocation",length = 50)
	    private String picupLocation;
	    
	    @Column(name = "status",length = 50)
	    private String status;
	    
	    @Column(name="price",length = 50)
	    private String price;

		public Long getBookingId() {
			return bookingId;
		}

		public void setBookingId(Long bookingId) {
			this.bookingId = bookingId;
		}

		public User getUser() {
			return user;
		}

		public void setUser(User user) {
			this.user = user;
		}

		

		public Package getPackage1() {
			return package1;
		}

		public void setPackage1(Package package1) {
			this.package1 = package1;
		}

		public Date getBookingDate() {
			return bookingDate;
		}

		public void setBookingDate(Date bookingDate) {
			this.bookingDate = bookingDate;
		}

		public String getTotalMembers() {
			return totalMembers;
		}

		public void setTotalMembers(String totalMembers) {
			this.totalMembers = totalMembers;
		}

		public String getChildrens() {
			return childrens;
		}

		public void setChildrens(String childrens) {
			this.childrens = childrens;
		}

		public String getPicupLocation() {
			return picupLocation;
		}

		public void setPicupLocation(String picupLocation) {
			this.picupLocation = picupLocation;
		}

		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}

		public String getPrice() {
			return price;
		}

		public void setPrice(String price) {
			this.price = price;
		}

	    

}
