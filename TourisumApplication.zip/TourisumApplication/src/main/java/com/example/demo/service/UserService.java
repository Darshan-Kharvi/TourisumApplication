package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import com.example.demo.entity.User;


public interface UserService {
    List<User> getAllUsers();
    Optional<User> getUserById(Integer id);
    User createUser(User user);
    User updateUser(Integer id, User userDetails);
    List<User> deleteUser(Integer id);
	User findbyusername(String accountMail, String accountPasswords);
	User forgotpass(String accountMail, String npass);
	User findByUserEmailId(String accountEmail);
	User findByEmail(String useremail);

}

