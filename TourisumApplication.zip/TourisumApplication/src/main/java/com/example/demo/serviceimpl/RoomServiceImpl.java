package com.example.demo.serviceimpl;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Room;
import com.example.demo.repository.RoomRepository;
import com.example.demo.service.RoomService;

import java.util.List;
import java.util.Optional;

@Service
public class RoomServiceImpl implements RoomService{

    @Autowired
    private RoomRepository roomRepository;

    public List<Room> getAllRoom() {
        return roomRepository.findAll();
    }

    public Optional<Room> getRoomById(Long id) {
        return roomRepository.findById(id);
    }

    public Room createRoom(Room room) {
        return roomRepository.save(room);
    }

    public Room updateRoom(Long id, Room roomDetails) {
        return roomRepository.findById(id).map(room -> {
            room.setRoomName(roomDetails.getRoomName());
            room.setLocation(roomDetails.getLocation());
            room.setDescription(roomDetails.getDescription());
            room.setRoomtype(roomDetails.getRoomtype());
            room.setImage(roomDetails.getImage());
            room.setPrice(roomDetails.getPrice());
            room.setBreakfast(roomDetails.getBreakfast());
            room.setMeal(roomDetails.getMeal());
            room.setCampfire(roomDetails.getCampfire());
            room.setDuration(roomDetails.getDuration());
            return roomRepository.save(room);
        }).orElseThrow(() -> new RuntimeException("Room not found with id " + id));
    }

    public List<Room> deleteRoom(Long id) {
    	roomRepository.deleteById(id);
        return roomRepository.findAll();
    }

	
}
