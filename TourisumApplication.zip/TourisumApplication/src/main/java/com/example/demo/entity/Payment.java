package com.example.demo.entity;

import java.util.Date;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "payments")
public class Payment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "payment_id")
    private Long paymentId;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "user_id")
    private User user;

    
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "booking_id")
    private PackageBooking booking;
    
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="room_id")
    private Room room;

    @Column(name = "payment_date")
    private Date paymentDate;

    @Column(name = "payment_amount")
    private Double paymentAmount;

    @Column(name = "payment_status",length = 50)
    private String paymentStatus;
    
    @Column(name="cardholder_name",length = 50)
    private String cardholderName;
    
    @Column(name="card_number",length = 50)
    private String cardNumber;
    
    @Column(name="exipire_date",length = 50)
    private String exipireDate;
    
    @Column(name="cvv",length = 50)
    private String cvv;
    
	public Long getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(Long paymentId) {
		this.paymentId = paymentId;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public PackageBooking getBooking() {
		return booking;
	}

	public void setBooking(PackageBooking booking) {
		this.booking = booking;
	}

	public Date getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}

	public Double getPaymentAmount() {
		return paymentAmount;
	}

	public void setPaymentAmount(Double paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public String getCardholderName() {
		return cardholderName;
	}

	public void setCardholderName(String cardholderName) {
		this.cardholderName = cardholderName;
	}

	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getExipireDate() {
		return exipireDate;
	}

	public void setExipireDate(String exipireDate) {
		this.exipireDate = exipireDate;
	}

	public String getCvv() {
		return cvv;
	}

	public void setCvv(String cvv) {
		this.cvv = cvv;
	}// Getters and Setters

	public Room getRoom() {
		return room;
	}

	public void setRoom(Room room) {
		this.room = room;
	}

	@Override
	public String toString() {
		return "Payment [paymentId=" + paymentId + ", user=" + user + ", booking=" + booking + ", room=" + room
				+ ", paymentDate=" + paymentDate + ", paymentAmount=" + paymentAmount + ", paymentStatus="
				+ paymentStatus + ", cardholderName=" + cardholderName + ", cardNumber=" + cardNumber + ", exipireDate="
				+ exipireDate + ", cvv=" + cvv + "]";
	}
    
	
	
}
