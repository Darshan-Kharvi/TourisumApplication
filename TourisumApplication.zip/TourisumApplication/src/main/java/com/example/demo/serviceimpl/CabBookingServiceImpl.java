package com.example.demo.serviceimpl;

import java.sql.Savepoint;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Cab;
import com.example.demo.entity.CabBooking;
import com.example.demo.entity.RoomBooking;
import com.example.demo.entity.User;
import com.example.demo.repository.CabBookingRepository;
import com.example.demo.service.CabBookingService;
import com.example.demo.service.CabService;
import com.example.demo.service.UserService;

@Service
public class CabBookingServiceImpl implements CabBookingService {

	@Autowired
	private UserService userService;
	
	@Autowired
	private CabService cabService;
	
	@Autowired
	private CabBookingRepository cabBookingRepository;
	
	@Autowired
   	private EmailService emailService;
	
	@Override
	public List<CabBooking> getAllBookings() {
		return cabBookingRepository.findAll();
	}

	@Override
	public List<CabBooking> getBookingById(int id) {
		return cabBookingRepository.findByUserUserId(id);
	}

//	@Override
//	public CabBooking createBooking(int userId, long cabId, CabBooking booking) {
//		CabBooking cabBooking=cabBookingRepository.findByUserUserIdAndCabCabIdAndBookingDate(userId, cabId, booking.getBookingDate());
//		if (cabBooking==null){
//			User user = userService.getUserById(userId).get();
//			Cab cab=cabService.getCabById(cabId).get();
//			booking.setUser(user);
//			booking.setCab(cab);
//			return cabBookingRepository.save(booking);
//		}else{
//			return null;
//		}
//	}
	
	@Override
	public CabBooking createBooking(int userId, long cabId, CabBooking booking) {
	    // Check if the same user already booked the same cab on the same date
	    CabBooking existingBooking = cabBookingRepository.findByUserUserIdAndCabCabIdAndBookingDate(
	        userId, cabId, booking.getBookingDate()
	    );

	    if (existingBooking == null) {
	        User user = userService.getUserById(userId).orElse(null);
	        Cab cab = cabService.getCabById(cabId).orElse(null);

	        if (user != null && cab != null) {
	            booking.setUser(user);
	            booking.setCab(cab);
	            CabBooking savedBooking = cabBookingRepository.save(booking);

	            // Send confirmation email
	            String message = "Hi <b>" + user.getFirstName() + " " + user.getLastName() + "</b>,<br>" +
	                             "Your cab booking (Cab ID: " + cabId + ") for " + booking.getBookingDate() +
	                             " has been successfully confirmed in our LastDestinationTripPlanner Application.";
	            String subject = "Cab Booking Confirmed";
	            emailService.sendEmail(user.getAccountEmail(), subject, message);

	            return savedBooking;
	        }
	    }

	    return null; // booking already exists or user/cab not found
	}


	@Override
	public CabBooking updateBooking(Long id, CabBooking bookingDetails) {
		return cabBookingRepository.findById(id).map(booking -> {
			booking.setBookingDate(booking.getBookingDate());
			return cabBookingRepository.save(booking);
		}).orElseThrow(() -> new RuntimeException("Booking not found with id " + id));

	}

	@Override
	public List<CabBooking> deleteBooking(Long id) {
		cabBookingRepository.deleteById(id);
		return cabBookingRepository.findAll();
	}

	@Override
	public String updateCabBookingStatus(long cabId) {
		int res= cabBookingRepository.updateCabBookingStatus(cabId);
		if(res>0) {
			return "Booking Updated SucessFully";
		}else {
			return "Problem in Updating";
		}
	}

	@Override
	public String cancelCabBooking(long bookingId) {
		int res= cabBookingRepository.cancelCabBooking(bookingId);
		if(res>0) {
			return "Booking Updated SucessFully";
		}else {
			return "Problem in Updating";
		}
	}

}
