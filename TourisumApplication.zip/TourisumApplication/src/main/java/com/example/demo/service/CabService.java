package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import com.example.demo.entity.Cab;


public interface CabService {
	List<Cab> getAllCab();
    Optional<Cab> getCabById(Long id);
    Cab createCab(Cab cab);
    Cab updateCab(Long id, Cab CabDetails);
    List<Cab> deleteCab(Long id);
}
