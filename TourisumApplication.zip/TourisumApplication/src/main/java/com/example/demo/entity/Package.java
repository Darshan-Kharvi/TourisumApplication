package com.example.demo.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


@Entity
@Table(name = "package")
public class Package{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "package_id")
    private Long packageId;

    @Column(name = "package_name",length = 50)
    private String packageName;

    @Column(name = "package_description")
    private String packageDescription;

    @Column(name = "package_type",length = 50)
    private String packagetype;
    
    @Column(name="image",length = 200) 
    private String image;

	@Column(name = "price")
    private Double packageprice;
	
	@Column(name="duration",length = 50)
	private String duration;
	
	@Column(name="cab",length = 50)
	private String cab;
	
	@Column(name="meals",length = 50)
	private String meal;
	
	@Column(name="breakfast",length = 50)
	private String breakfast;
	
	@Column(name="sightvisit",length = 50)
	private String sightvisit;
	
	@Column(name="room",length = 50)
	private String room;
	
	@Column(name="campfire",length = 50)
	private String campfire;
	
    @Column(name = "available_seats")
    private Integer availableSeats;

	public Long getPackageId() {
		return packageId;
	}

	public void setPackageId(Long packageId) {
		this.packageId = packageId;
	}

	public String getPackageName() {
		return packageName;
	}

	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}

	public String getPackageDescription() {
		return packageDescription;
	}

	public void setPackageDescription(String packageDescription) {
		this.packageDescription = packageDescription;
	}

	public String getPackagetype() {
		return packagetype;
	}

	public void setPackagetype(String packagetype) {
		this.packagetype = packagetype;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public Double getPackageprice() {
		return packageprice;
	}

	public void setPackageprice(Double packageprice) {
		this.packageprice = packageprice;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public String getCab() {
		return cab;
	}

	public void setCab(String cab) {
		this.cab = cab;
	}

	public String getMeal() {
		return meal;
	}

	public void setMeal(String meal) {
		this.meal = meal;
	}

	public String getBreakfast() {
		return breakfast;
	}

	public void setBreakfast(String breakfast) {
		this.breakfast = breakfast;
	}

	public String getSightvisit() {
		return sightvisit;
	}

	public void setSightvisit(String sightvisit) {
		this.sightvisit = sightvisit;
	}

	public String getRoom() {
		return room;
	}

	public void setRoom(String room) {
		this.room = room;
	}

	public String getCampfire() {
		return campfire;
	}

	public void setCampfire(String campfire) {
		this.campfire = campfire;
	}

	public Integer getAvailableSeats() {
		return availableSeats;
	}

	public void setAvailableSeats(Integer availableSeats) {
		this.availableSeats = availableSeats;
	}
	  
    
}