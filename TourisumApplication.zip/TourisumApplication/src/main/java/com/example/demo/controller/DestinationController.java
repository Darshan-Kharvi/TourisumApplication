package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Cab;
import com.example.demo.entity.Destination;
import com.example.demo.service.DestinationService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/api/destination")
public class DestinationController {
	
	@Autowired
	private DestinationService destinationService;

	
	 @GetMapping
	 public List<Destination> getAllDestination(){
		 return destinationService.getAllDestination();
	 }
	
	 
	 @GetMapping("/getDestinationById/{id}")
	    public Optional<Destination> getDestinationById(@PathVariable Long id){
	        return destinationService.getDestinationById(id);
	 }
	 
	 @PostMapping
	    public Destination createDestination(@RequestBody Destination destination) {
	        return destinationService.createDestination(destination);
	 }
	 
	 @PutMapping("/updateDestination/{id}")
	    public Destination updateDestination(@PathVariable Long id, @RequestBody Destination destination) {
	        return destinationService.updateDestination(id, destination);
	 }

	 @DeleteMapping("/{id}")
	    public List<Destination> deleteDestination(@PathVariable Long id) {
	       return destinationService.deleteDestination(id);
	 }

}
