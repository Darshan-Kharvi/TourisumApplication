package com.example.demo.service;
import java.util.List;
import java.util.Optional;
import com.example.demo.entity.Review;

public interface ReviewService {
	  List<Review> getAllReviews();
	  Optional<Review> getReviewsById(Long id);
	  Review createReview( int userId, Review review);
	  Review updateReview(Long id, Review reviewDetails);
	  List<Review> deleteReview(Long id);
	  List<Review>getReviewsByUserId(Long userId);
	  
}
