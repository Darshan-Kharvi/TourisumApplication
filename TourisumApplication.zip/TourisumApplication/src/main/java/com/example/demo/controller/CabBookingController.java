package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.CabBooking;
import com.example.demo.entity.RoomBooking;
import com.example.demo.service.CabBookingService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/api/cabbookings")
public class CabBookingController {
	 @Autowired
	 private CabBookingService cabbookingService;
	 
	 @GetMapping
	    public List<CabBooking> getAllBookings() {
	        return cabbookingService.getAllBookings();
	    }
	 
	  @GetMapping("/user/{userId}")
	    public List<CabBooking> getBookingById(@PathVariable ("userId")int id) {
	        return cabbookingService.getBookingById(id);
	    }
	  
	  @PostMapping("/{userId}/{cabId}")
	    public CabBooking createBooking(@PathVariable("userId") int userId,@PathVariable("cabId") long cabId,@RequestBody CabBooking booking) {
	        return cabbookingService.createBooking(userId,cabId,booking);
	    }
	  
	  @PutMapping("/{id}")
	    public CabBooking updateBooking(@PathVariable Long id, @RequestBody CabBooking booking) {
	        return cabbookingService.updateBooking(id, booking);
	    }
	  
	  @DeleteMapping("/{id}")
	    public List<CabBooking> deleteBooking(@PathVariable Long id) {
	       return cabbookingService.deleteBooking(id);
		
	    }
	  
	  @PutMapping("/cabstatusupdate/{cabId}")
	    public String updateCabBookingStatus(@PathVariable("cabId") long cabId, @RequestBody CabBooking booking){
	    return cabbookingService.updateCabBookingStatus(cabId);
	    }
	  
	  @PutMapping("/cancel/{bookingId}")
	    public String cancelCabBooking(@PathVariable("bookingId") long bookingId, @RequestBody CabBooking booking){
	    return cabbookingService.cancelCabBooking(bookingId);
	    }
	    
	  
	  

}
