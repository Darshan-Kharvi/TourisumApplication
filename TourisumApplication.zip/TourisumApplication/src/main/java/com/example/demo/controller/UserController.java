package com.example.demo.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.demo.entity.User;
import com.example.demo.service.UserService;

import jakarta.validation.Valid;

import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin(origins="http://localhost:4200", allowCredentials = "true")
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping
    public List<User> getAllUsers() {
        return userService.getAllUsers();
    }

    @GetMapping("/getUserById/{id}")
    public Optional<User> getUserById(@PathVariable Integer id) {
        return userService.getUserById(id);
    }

    @PostMapping
    public User createUser(@Valid @RequestBody User user) {
        return userService.createUser(user);
    }

    @PutMapping("/{id}")
    public User updateUser(@PathVariable Integer id, @Valid @RequestBody User user) {
        return userService.updateUser(id, user);
    }

    @DeleteMapping("/deleteUser/{id}")
    public List<User> deleteUser(@PathVariable Integer id) {
       return userService.deleteUser(id);
    }
    
	@GetMapping("/{mail}/{pass}")
	public User findbyusername(@PathVariable("mail")String accountMail,@PathVariable("pass")String accountPasswords )
	{
		return userService.findbyusername(accountMail, accountPasswords);
	}
	
	@PutMapping("/findbymail/{mail}/{npassword}")
	public User findByEmail(@PathVariable("mail") String accountMail,@PathVariable String npassword,@RequestBody User user) {
		System.out.println("Changing the password");
		return userService.forgotpass(accountMail,npassword);
	}
	
	@GetMapping("/findUserByEmail/{email}")
	public ResponseEntity<User> findUserByEmail(@PathVariable("email") String emailid)
	{
		System.out.println("checking the email id "+emailid);
		return new ResponseEntity<User>(userService.findByUserEmailId(emailid),HttpStatus.OK);
	}
	
	@GetMapping("/findbyemail/{mail}")
	public User findByEmail(@PathVariable("mail") String usermail)
	{
	    User user=userService.findByEmail(usermail);
		System.out.println(user);
		return user;
	}
	
}

