package com.example.demo.serviceimpl;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Package;
import com.example.demo.repository.PackageRepository;
import com.example.demo.service.PackageService;

import java.util.List;
import java.util.Optional;

@Service
public class PackageServiceImpl implements PackageService {

    @Autowired
    private PackageRepository packageRepository;

    public List<Package> getAllPackage() {
        return packageRepository.findAll();
    }

    public Optional<Package> getPackageById(Long id) {
        return packageRepository.findById(id);
    }

    public Package createPackage(Package tour) {
        return packageRepository.save(tour);
    }

    public Package updatePackage(Long id, Package packageDetails) {
        return packageRepository.findById(id).map(packages -> {
            packages.setPackageName(packageDetails.getPackageName());
            packages.setPackageDescription(packageDetails.getPackageDescription());
            packages.setPackageprice(packageDetails.getPackageprice());
            packages.setAvailableSeats(packageDetails.getAvailableSeats());
            packages.setRoom(packageDetails.getRoom());
            packages.setBreakfast(packages.getBreakfast());
            packages.setCab(packageDetails.getCab());
            packages.setCampfire(packageDetails.getCampfire());
            packages.setMeal(packageDetails.getMeal());
            packages.setDuration(packageDetails.getDuration());
            packages.setImage(packageDetails.getImage());
            packages.setPackagetype(packageDetails.getPackagetype());
            packages.setSightvisit(packageDetails.getSightvisit());
            return packageRepository.save(packages);
        }).orElseThrow(() -> new RuntimeException("Tour not found with id " + id));
    }

    public List<Package> deletePackage(Long id) {
    	packageRepository.deleteById(id);
        return packageRepository.findAll();
    }
}
