package com.example.demo.repository;

import java.util.Date;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.entity.CabBooking;

import jakarta.transaction.Transactional;
import java.time.LocalDate;

public interface CabBookingRepository extends JpaRepository<CabBooking, Long> {

	public List<CabBooking> findByUserUserId(int userId);
	
	
	 @Transactional
	 @Modifying
	 @Query(value="update cabbookings b set b.status='BOOKED' where b.booking_id=?1",nativeQuery=true)
		public int updateCabBookingStatus(long cabId);
	 

//	 @Transactional
//	 @Modifying
//	 @Query(value="update cabbookings b set b.status='CANCELED' where b.booking_id=?1",nativeQuery=true)
//		public int cancelCabBooking(long bookingId);
	 
//	 @Transactional
//	 @Modifying
//	 @Query(value = "UPDATE cabbookings b SET b.status = 'CANCELED', b.booking_date = NULL WHERE b.booking_id = ?1", nativeQuery = true)
//	 public int cancelCabBooking(long bookingId);
	 
	 @Transactional
	 @Modifying
	 @Query(value = "UPDATE cabbookings b SET b.status = 'CANCELED', b.booking_date = CURRENT_TIMESTAMP WHERE b.booking_id = ?1", nativeQuery = true)
	 public int cancelCabBooking(long bookingId);
	 


	 
	 public CabBooking findByUserUserIdAndCabCabIdAndBookingDate(int userId, long bookingId, Date bookingDate);
	
}
