package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.Package;
import com.example.demo.service.PackageService;

import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/api/pacakge")
public class PackageController {

    @Autowired
    private PackageService tourService;

    @GetMapping
    public List<Package> getAllPackage() {
        return tourService.getAllPackage();
    }

    @GetMapping("/getPackageById/{id}")
    public Optional<Package> getPackageById(@PathVariable Long id) {
        return tourService.getPackageById(id);
    }

    @PostMapping
    public Package createPackage(@RequestBody Package tour) {
        return tourService.createPackage(tour);
    }

    @PutMapping("/updatePackage/{id}")
    public Package updatePackage(@PathVariable Long id, @RequestBody Package tour) {
        return tourService.updatePackage(id, tour);
    }

    @DeleteMapping("/deletePackage/{id}")
    public List<Package> deletePackage(@PathVariable Long id) {
        return tourService.deletePackage(id);
    }
}

