package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.CabBooking;
import com.example.demo.entity.RoomBooking;

public interface CabBookingService {
	    List<CabBooking> getAllBookings();
	    List<CabBooking> getBookingById(int id);
	    CabBooking createBooking(int userId, long cabId, CabBooking booking);
	    CabBooking updateBooking(Long id, CabBooking bookingDetails);
	    List<CabBooking> deleteBooking(Long id);
	    String updateCabBookingStatus(long cabId);
	    String cancelCabBooking(long bookingId);
	    
}
