package com.example.demo.service;

import com.example.demo.entity.Bankserver;

public interface BankserverService {

	 Bankserver saveDetails(Bankserver bankserver);
	 Bankserver findByCardCvv(Long cCardnumber, Integer cCvvnumber, String expiryDate);
	 Bankserver findByUpi(String cUpi);
	 Bankserver cardValidation(Bankserver bankserver);
	
	

}