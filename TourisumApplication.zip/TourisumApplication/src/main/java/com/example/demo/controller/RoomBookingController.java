package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.PackageBooking;
import com.example.demo.entity.RoomBooking;
import com.example.demo.service.RoomBookingService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/api/roombookings")
public class RoomBookingController {
	 @Autowired
	 private RoomBookingService roombookingService;
	 
	 
	 	@GetMapping
	    public List<RoomBooking> getAllBookings() {
	        return roombookingService.getAllBookings();
	    }

	    @GetMapping("/user/{userId}")
	    public List<RoomBooking> getBookingById(@PathVariable ("userId")int id) {
	        return roombookingService.getBookingById(id);
	    }

	    @PostMapping("/{userId}/{roomId}")
	    public RoomBooking createBooking(@PathVariable("userId") int userId,@PathVariable("roomId") long roomId,@RequestBody RoomBooking booking) {
	        return roombookingService.createBooking(userId,roomId,booking);
	    }

	    @PutMapping("/{id}")
	    public RoomBooking updateBooking(@PathVariable Long id, @RequestBody RoomBooking booking) {
	        return roombookingService.updateBooking(id, booking);
	    }

	    @DeleteMapping("/{id}")
	    public List<RoomBooking> deleteBooking(@PathVariable Long id) {
	       return roombookingService.deleteBooking(id);
		
	    }
	    
	    @PutMapping("/roomstatusupdate/{roomId}")
	    public String updateRoomBookingStatus(@PathVariable("roomId") long roomId, @RequestBody RoomBooking booking){
	    return roombookingService.updateRoomBookingStatus(roomId);
	    }
	    
//	    @PutMapping("/cancel/{bookingId}")
//	    public  String cancelRoomBooking(@PathVariable long bookingId, @RequestBody RoomBooking booking) {
//	      return roombookingService.cancelRoomBooking(bookingId);
//	       
//	    }
	    
	    @PutMapping("/cancel/{bookingId}")
	    public  String cancelRoomBooking(@PathVariable long bookingId) {
	      return roombookingService.cancelRoomBooking(bookingId);
	       
	    }
}
