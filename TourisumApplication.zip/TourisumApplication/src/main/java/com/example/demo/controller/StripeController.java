/*
 * package com.example.demo.controller;
 * 
 * import com.example.demo.serviceimpl.StripeService; import
 * com.stripe.exception.StripeException; import com.stripe.model.Event; import
 * com.stripe.net.Webhook;
 * 
 * import org.springframework.http.HttpStatus; import
 * org.springframework.http.ResponseEntity; import
 * org.springframework.web.bind.annotation.*;
 * 
 * import java.util.List; import java.util.Map;
 * 
 * @RestController
 * 
 * @RequestMapping("/api/payment")
 * 
 * @CrossOrigin(origins="http://localhost:4200") // Allow requests from Angular
 * public class StripeController {
 * 
 * private final StripeService stripeService;
 * 
 * public StripeController(StripeService stripeService) { this.stripeService =
 * stripeService; }
 * 
 * @PostMapping("/create-checkout-session") public Map<String, String>
 * createCheckoutSession(@RequestBody Map<String, Object> request) throws
 * StripeException { System.out.println(request); List<String> productNames =
 * (List<String>) request.get("productNames"); // List<Long> prices =
 * (List<Long>) request.get("prices"); // List<Long> quantities = (List<Long>)
 * request.get("quantities");
 * 
 * String checkoutUrl = stripeService.createCheckoutSession(productNames prices,
 * quantities); // return Map.of("checkoutUrl", checkoutUrl); return null; }
 * 
 * @PostMapping("/webhook") public ResponseEntity<String>
 * handleWebhook(@RequestBody String payload, @RequestHeader("Stripe-Signature")
 * String sigHeader) { try { Event event = Webhook.constructEvent(payload,
 * sigHeader, "your_webhook_secret"); if
 * ("checkout.session.completed".equals(event.getType())) { // Payment
 * successful, update your DB } return ResponseEntity.ok("Success"); } catch
 * (Exception e) { return
 * ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Webhook Error"); } }
 * 
 * }
 */