/*
 * package com.example.demo.serviceimpl; import
 * com.example.demo.config.StripeConfig; import com.stripe.Stripe; import
 * com.stripe.exception.StripeException; import
 * com.stripe.model.checkout.Session; import
 * com.stripe.param.checkout.SessionCreateParams; import
 * org.springframework.beans.factory.annotation.Value; import
 * org.springframework.stereotype.Service;
 * 
 * import java.util.List;
 * 
 * @Service public class StripeService {
 * 
 * @Value("${stripe.api.key}") private String stripeApiKey;
 * 
 * private final StripeConfig stripeConfig;
 * 
 * public StripeService(StripeConfig stripeConfig) { this.stripeConfig =
 * stripeConfig; }
 * 
 * public void printApiKey() { System.out.println("Stripe API Key: " +
 * stripeConfig.getApiKey()); }
 * 
 * public String createCheckoutSession(List<String> productNames, List<Integer>
 * prices, List<Integer> quantities) throws StripeException { Stripe.apiKey =
 * stripeApiKey;
 * 
 * // Create line items for checkout List<SessionCreateParams.LineItem>
 * lineItems = new java.util.ArrayList<>(); for (int i = 0; i <
 * productNames.size(); i++) { lineItems.add(
 * SessionCreateParams.LineItem.builder() .setPriceData(
 * SessionCreateParams.LineItem.PriceData.builder() .setCurrency("usd")
 * .setUnitAmount(prices.get(i)) // Amount in cents .setProductData(
 * SessionCreateParams.LineItem.PriceData.ProductData.builder()
 * .setName(productNames.get(i)) .build() ) .build() )
 * .setQuantity(quantities.get(i)) .build() ); }
 * 
 * // Create checkout session SessionCreateParams params =
 * SessionCreateParams.builder()
 * //.setPaymentMethodTypes(List.of(SessionCreateParams.PaymentMethodType.CARD))
 * .setMode(SessionCreateParams.Mode.PAYMENT)
 * .setSuccessUrl("http://localhost:4200/payment-success") // Redirect on
 * success .setCancelUrl("http://localhost:4200/payment-failed") // Redirect on
 * cancel .addAllLineItem(lineItems) .build();
 * 
 * Session session = Session.create(params); return session.getUrl(); // Return
 * the checkout URL } }
 */