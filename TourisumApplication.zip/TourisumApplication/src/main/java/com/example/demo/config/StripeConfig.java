


//This Code is Not Working



//  package com.example.demo.config;
// 
//
//  import org.springframework.boot.context.properties.ConfigurationProperties;
//  import org.springframework.context.annotation.Configuration;
//
//  @Configuration
//  @ConfigurationProperties(prefix = "stripe.api.key")
//  public class StripeConfig {
//
//      private String apiKey;
//
//      public String getApiKey() {
//          return apiKey;
//      }
//
//      public void setApiKey(String apiKey) {
//          this.apiKey = apiKey;
//      }
//  }
