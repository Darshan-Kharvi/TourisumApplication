import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Destination } from '../model/destination';

@Injectable({
  providedIn: 'root'
})
export class DestinationService {

  constructor(private httpclient:HttpClient) { }

  url="http://localhost:8089/api/destinations";
  
addDestination(destination:Destination)
{
  return this.httpclient.post(`${this.url}`,destination);
}


getAllDestination()
{
  return this.httpclient.get(`${this.url}`);
}

deleteDestination(id:any)
{
  return this.httpclient.delete<Destination>(`${this.url}/${id}`);
}

getDestinationById(destinationId: number)
{
  return this.httpclient.get<Destination>(`${this.url}/getDestinationById/${destinationId}`);
}

updateDestination(destinationId: number, updatedData: any) 
{
  return this.httpclient.put(`${this.url}/updateDestination/${destinationId}`, updatedData);
}

}

