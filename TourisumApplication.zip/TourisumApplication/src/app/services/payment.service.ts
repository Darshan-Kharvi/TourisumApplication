import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class paymentService {

  constructor(private httpclient:HttpClient) { }

  url="http://localhost:8089/api/payments"

   addpayment(payment:any,userId:any,bookingId:any,roomId:any,roomPrice:any)
    {
      console.log("inside the service");
      console.log(payment);
     return this.httpclient.post(`${this.url}/${userId}/${bookingId}/${roomId}/${roomPrice}`,payment);
    
    }

    getPaymentById(userId:any)
    {
      return this.httpclient.get(`${this.url}/user/${userId}`);
    }

}
