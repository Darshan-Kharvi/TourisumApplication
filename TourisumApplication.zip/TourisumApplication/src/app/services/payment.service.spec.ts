import { TestBed } from '@angular/core/testing';

import { PackagepaymentService } from './payment.service';

describe('PackagepaymentService', () => {
  let service: PackagepaymentService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PackagepaymentService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
