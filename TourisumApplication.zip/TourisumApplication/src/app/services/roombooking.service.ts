import { HttpBackend, HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { RoomBooking } from '../model/roombooking';

@Injectable({
  providedIn: 'root'
})
export class RoombookingService {

  constructor(private httpclient:HttpClient) { }

  url="http://localhost:8089/api/roombookings";

  addRoomBooking(roombooking:RoomBooking,userId:any,roomId:any)
  {
   return this.httpclient.post(`${this.url}/${userId}/${roomId}`,roombooking);
  }

  getAllRoomBookings()
  {
    return this.httpclient.get(`${this.url}`);
  }

  deleteRoomBooking(id:any)
  {
    return this.httpclient.delete(`${this.url}/${id}`);
  }

  getRoomBookingById(userId:any)
  {
    return this.httpclient.get(`${this.url}/user/${userId}`);
  }
}
