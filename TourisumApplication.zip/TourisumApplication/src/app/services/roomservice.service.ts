import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Room } from '../model/room';

@Injectable({
  providedIn: 'root'
})
export class RoomserviceService {

  constructor(private httpclient:HttpClient) { }

   url="http://localhost:8089/api/room";
    
  addRoom(room:Room)
  {
    return this.httpclient.post(`${this.url}`,room);
  }
  
  getAllRoom()
  {
    return this.httpclient.get(`${this.url}`);
  }
  
  deleteRoom(id:any)
  {
    return this.httpclient.delete<Room>(`${this.url}/${id}`);
  }
  
  getRoomById(roomId: number)
  {
    return this.httpclient.get<Room>(`${this.url}/getRoomById/${roomId}`);
  }
  
  updateRoom(roomId: number, updatedData: any) 
  {
    return this.httpclient.put(`${this.url}/updateRoom/${roomId}`, updatedData);
  }
  
}
