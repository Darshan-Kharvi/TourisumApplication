import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { PackageBooking } from '../model/pacakagebooking';

@Injectable({
  providedIn: 'root'
})
export class PackagebookingService {

  constructor(private httpclient:HttpClient) { }

  url="http://localhost:8089/api/packagebookings";

  addBooking(packagebooking:PackageBooking,userId:any,packageId:any)
  {
   return this.httpclient.post(`${this.url}/${userId}/${packageId}`,packagebooking);
  }
  getAllBookings()
  {
    return this.httpclient.get(`${this.url}`);
  }

  deleteBookings(id:any)
  {
    return this.httpclient.delete(`${this.url}/${id}`);
  }

  getPackageBookingById(userId:any)
  {
    return this.httpclient.get(`${this.url}/user/${userId}`);
  }

  

}
