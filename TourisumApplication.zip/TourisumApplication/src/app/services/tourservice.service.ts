import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Tours } from '../model/tours';


@Injectable({
  providedIn: 'root'
})
export class TourserviceService {

  constructor(private httpcilent:HttpClient) { }

  url="http://localhost:8089/api/tours";

  addTours(tour:Tours)
  {
    return this.httpcilent.post(`${this.url}`,tour);
  }

  getAllTours()
  {
    return this.httpcilent.get(`${this.url}`);
  }

  deleteTours(tourid:any){
    return this.httpcilent.delete(`${this.url}/deleteTour/${tourid}`);
  }

  getToursById(tourId:any)
  {
    return this.httpcilent.get(`${this.url}/getTourById/${tourId}`)
  }

  updateTour(tourId:any,updatedData: any)
  {
    return this.httpcilent.put(`${this.url}/updateTour/${tourId}`,updatedData);
  }

}
