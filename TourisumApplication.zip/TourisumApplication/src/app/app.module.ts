import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './Component/home/home.component';
import { NavbarComponent } from './Component/navbar/navbar.component';

import { RegisterComponent } from './Component/register/register.component';
import { LoginComponent } from './Component/login/login.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ForgotpasswordComponent } from './Component/forgotpassword/forgotpassword.component';
import { AdminloginComponent } from './Component/admincomponents/adminlogin/adminlogin.component';
import { AdminhomeComponent } from './Component/admincomponents/adminhome/adminhome.component';
import { AdddestinationComponent } from './Component/admincomponents/adddestination/adddestination.component';
import { AddtoursComponent } from './Component/admincomponents/addtours/addtours.component';
import { ViewdestinationComponent } from './Component/admincomponents/viewdestination/viewdestination.component';
import { ViewusersComponent } from './Component/admincomponents/viewusers/viewusers.component';
import { ViewtoursComponent } from './Component/admincomponents/viewtours/viewtours.component';
import { UpdatedestinationComponent } from './Component/admincomponents/updatedestination/updatedestination.component';
import { UpdatetoursComponent } from './Component/admincomponents/updatetours/updatetours.component';
import { DestinationComponent } from './Component/destination/destination.component';
import { ToursComponent } from './Component/tours/tours.component';
import { ProfileComponent } from './Component/profile/profile.component';
import { WelcomeComponent } from './Component/welcome/welcome.component';
import { RoomComponent } from './Component/room/room.component';
import { PackageComponent } from './Component/package/package.component';
import { AddroomComponent } from './Component/admincomponents/addroom/addroom.component';
import { ViewroomComponent } from './Component/admincomponents/viewroom/viewroom.component';
import { UpdateroomComponent } from './Component/admincomponents/updateroom/updateroom.component';
import { AddpackageComponent } from './Component/admincomponents/addpackage/addpackage.component';
import { ViewpackageComponent } from './Component/admincomponents/viewpackage/viewpackage.component';
import { UpdatepackageComponent } from './Component/admincomponents/updatepackage/updatepackage.component';
import { EditprofileComponent } from './Component/editprofile/editprofile.component';
import { PackagebookingComponent } from './Component/packagebooking/packagebooking.component';
import { ViewpackagebookingsComponent } from './Component/admincomponents/viewpackagebookings/viewpackagebookings.component';
import { MypackagebookingComponent } from './Component/mypackagebooking/mypackagebooking.component';
import { RoombookingComponent } from './Component/roombooking/roombooking.component';
import { ViewroombookingsComponent } from './Component/admincomponents/viewroombookings/viewroombookings.component';
import { MyroombookingComponent } from './Component/myroombooking/myroombooking.component';
import { paymentComponent } from './Component/payment/payment.component';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ViewallpaymentsComponent } from './Component/viewallpayments/viewallpayments.component';





@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    NavbarComponent,
    LoginComponent,
    RegisterComponent,
    ForgotpasswordComponent,
    AdminloginComponent,
    AdminhomeComponent,
    AdddestinationComponent,
    AddtoursComponent,
    ViewdestinationComponent,
    ViewusersComponent,
    ViewtoursComponent,
    UpdatedestinationComponent,
    UpdatetoursComponent,
    DestinationComponent,
    ToursComponent,
    ProfileComponent,
    WelcomeComponent,
    RoomComponent,
    PackageComponent,
    AddroomComponent,
    ViewroomComponent,
    UpdateroomComponent,
    AddpackageComponent,
    ViewpackageComponent,
    UpdatepackageComponent,
    EditprofileComponent,
    PackagebookingComponent,
    ViewpackagebookingsComponent,
    MypackagebookingComponent,
    RoombookingComponent,
    ViewroombookingsComponent,
    MyroombookingComponent,
    paymentComponent,
    ViewallpaymentsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    MatInputModule,
    MatButtonModule,
    MatCardModule
   
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
