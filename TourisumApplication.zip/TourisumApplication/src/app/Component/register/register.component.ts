import { Component } from '@angular/core';
import { User } from '../../model/user';
import { UserService } from '../../services/user.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-register',
  standalone: false,
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {
  ccpassword:any;
  user = new User();
  isFirstNameValid: boolean = true;
  isLastNameValid: boolean = true;
  emailValid: boolean = true;
  isMobileValid: boolean = true;
  isPasswordValid: boolean = true;
  isAddressValid: boolean = true;
  isFavouriteValid: boolean = true;
  disableSubmit:boolean=true;
  a: any;
  b: any;




  constructor(private userService: UserService,private route:ActivatedRoute,private router:Router){}

registerUser()
{
this.userService.registerUser(this.user).subscribe(
  (Response:any)=>
  {
    if(Response!=null)
    {
      alert("registered sucessfully");
      this.router.navigate(['signinurl']);
    }else
    alert("registraition failed");
  }
);
}
firstnamevalid(event: any) {
  event.target.value = event.target.value.trim().length > 0 ? event.target.value : event.target.value.trim(); //
  console.log(event.target.value)
  this.user.firstName = event.target.value
  this.isFirstNameValid = this.user.firstName.match(/^[A-Za-z\s]*$/) && this.user.firstName.length > 2 ? true : false
  console.log(this.isFirstNameValid);
  this.checkValidation();
}
lastnamevalid(event: any) {
  event.target.value = event.target.value.trim().length > 0 ? event.target.value : event.target.value.trim();
  this.user.lastName = event.target.value
  this.isLastNameValid = this.user.lastName.match("^[A-Za-z\s]*$") && this.user.lastName.length > 0 ? true : false
  console.log(this.isLastNameValid);
  this.checkValidation();
}
emailvalid(event: any) {
  event.target.value = event.target.value.trim();
  this.user.accountEmail = event.target.value
  this.emailValid = this.user.accountEmail.match("^[a-zA-Z0-9._-]+@[a-zA-Z0-9-]+\\.[a-zA-Z.]{2,4}$") ? true : false
  console.log(this.emailValid);
  this.checkValidation();
}
mobileValid(event: any) {
  event.target.value = event.target.value.trim();
  this.user.phoneNo = event.target.value
  let m = this.user.phoneNo.split("");
  console.log(m)
  let n = new Set(m);
  console.log(new Set(m));
  console.log(n.size)

  this.isMobileValid = this.user.phoneNo.match(/^[6-9][0-9]{9}$/) && n.size > 2 ? true : false
  console.log(this.isMobileValid)
  this.checkValidation();
}
passwordValid(event: any) {
  event.target.value = event.target.value.trim();
  this.user.password = event.target.value
  this.isPasswordValid = this.user.password.match("^[a-zA-Z0-9._-]+[@|_|&|%|*|$|-][a-zA-Z0-9-]{2,7}$") ? true : false
  console.log(this.passwordValid)
  this.checkValidation();
}
cPasswordValid(event: any) {
  event.target.value = event.target.value.trim();
  this.ccpassword = event.target.value
  this.isPasswordValid = this.ccpassword.match("^[a-zA-Z0-9._-]+[@|_|&|%|*|$|-][a-zA-Z0-9-]{2,7}$") ? true : false
  console.log(this.passwordValid)
  this.checkValidation();
}
addressValid(event: any) {
  event.target.value = event.target.value.trim().length > 0 ? event.target.value : event.target.value.trim();
  this.user.address = event.target.value
  this.isAddressValid = this.user.address.match("^[a-zA-Z0-9. ,-]{15,50}$") ? true : false
  console.log(this.addressValid)
  this.checkValidation();
}
checkValidation(){
  this.disableSubmit=this.isFirstNameValid && this.isLastNameValid && this.isMobileValid && this.emailValid && this.isAddressValid && this.isPasswordValid && this.user.firstName!='' && this.user.lastName!='' && this.user.lastName!='' && this.user.phoneNo!='' && this.user.password!='' && this.ccpassword!='' ?false:true;
  return this.disableSubmit;
}

}
