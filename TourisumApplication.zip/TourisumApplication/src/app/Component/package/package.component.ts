import { Component, OnInit } from '@angular/core';
import { Package } from '../../model/package';
import { PackageserviceService } from '../../services/packageservice.service';
import { ActivatedRoute, Router } from '@angular/router';
import { User } from '../../model/user';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-package',
  standalone: false,
  templateUrl: './package.component.html',
  styleUrl: './package.component.css'
})
export class PackageComponent implements OnInit {
packageList:Package[]=[];
packages=new Package();



constructor(private packageservice:PackageserviceService,private router:Router,private route:ActivatedRoute,private userService:UserService){}
ngOnInit(): void {

  this.packageservice.getAllPackage().subscribe(
    (response:any)=>{
      this.packageList=response;
    });
}

booking(packageId:any, packagePrice: number){
  this.router.navigate(['/packagebookingurl',packageId] ,{ queryParams: { id: packageId, price: packagePrice } });
}

}
