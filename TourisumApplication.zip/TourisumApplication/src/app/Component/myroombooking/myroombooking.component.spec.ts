import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MyroombookingComponent } from './myroombooking.component';

describe('MyroombookingComponent', () => {
  let component: MyroombookingComponent;
  let fixture: ComponentFixture<MyroombookingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [MyroombookingComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MyroombookingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
