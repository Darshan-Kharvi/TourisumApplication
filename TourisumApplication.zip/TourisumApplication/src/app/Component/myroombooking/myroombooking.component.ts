import { Component, OnDestroy, OnInit } from '@angular/core';
import { RoomBooking } from '../../model/roombooking';
import { RoombookingService } from '../../services/roombooking.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-myroombooking',
  standalone: false,
  templateUrl: './myroombooking.component.html',
  styleUrl: './myroombooking.component.css'
})
export class MyroombookingComponent implements OnInit {
roomBookingId:any;
roomBookings:RoomBooking[]=[];
userId:any;

constructor(private roombookingservice:RoombookingService,private route:ActivatedRoute,private Router:Router){}

ngOnInit(): void {

  this.userId=sessionStorage.getItem('userId');
  console.log(this.userId);

 this.roomBookingId=this.route.snapshot.params['id'];
 console.log(this.userId);
  this.roombookingservice.getRoomBookingById(this.userId).subscribe(
    (response:any)=>{
      console.log( response);
      this.roomBookings=response;
    }
  )
}
}
