import { Component, OnInit } from '@angular/core';
import { Payment } from '../../model/payment';
import { paymentService } from '../../services/payment.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-viewallpayments',
  standalone: false,
  templateUrl: './viewallpayments.component.html',
  styleUrl: './viewallpayments.component.css'
})
export class ViewallpaymentsComponent implements OnInit {
  paymentId:any;
  payments:Payment[]=[];
  userId:any;

  constructor(private paymentservice:paymentService,private route:ActivatedRoute,private router:Router){}

  ngOnInit(): void {
    
  this.userId=sessionStorage.getItem('userId');
  console.log(this.userId);

  this.paymentId=this.route.snapshot.params['id'];
  console.log(this.userId);
  
  this.paymentservice.getPaymentById(this.userId).subscribe(
   (response:any)=>{
    console.log( response);
    this.payments=response;
   });

  }
}
