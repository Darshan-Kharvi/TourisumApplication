import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-editprofile',
  standalone: false,
  templateUrl: './editprofile.component.html',
  styleUrl: './editprofile.component.css'
})
export class EditprofileComponent implements OnInit {
user:any;
userId:any;

constructor(private userservice:UserService,private route:ActivatedRoute,private router:Router){}

ngOnInit(): void {
 this.userId=this.route.snapshot.params['id'];
 console.log('Extracted userId:', this.userId);
  this.userservice.getUserById(this.userId).subscribe(
    (response:any)=>{
      this.user=response;
    });
}
onSubmit(){
  this.userservice.updateUser(this.userId,this.user).subscribe(
    ()=>{
      alert('User Details Updated Sucessfully')
      this.router.navigate(['/profileurl',this.userId]);
    });
}

}
