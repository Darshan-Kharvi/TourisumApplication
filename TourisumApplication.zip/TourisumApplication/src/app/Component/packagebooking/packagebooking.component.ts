import { Component, OnInit } from '@angular/core';
import { PackageBooking } from '../../model/pacakagebooking';
import { PackagebookingService } from '../../services/packagebooking.service';
import { ActivatedRoute, Router } from '@angular/router';
import { User } from '../../model/user';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-packagebooking',
  standalone: false,
  templateUrl: './packagebooking.component.html',
  styleUrl: './packagebooking.component.css'
})
export class PackagebookingComponent implements OnInit {
booking=new PackageBooking();
packageId:any | null = null;
bookingId:any;
basePrice: number = 0;
totalPrice: number = 0;
totalMembers: number = 1;
//user: User | null = null;
user:any;
userId:any;
roomId:number=0;


constructor(private userService:UserService,private packagebookingservice:PackagebookingService,private route:ActivatedRoute,private router:Router){}

ngOnInit(): void {

  this.userId=sessionStorage.getItem('userId');
 this.userService.getUserById(this.userId).subscribe(
  (Response:any)=>
  {
    this.user=Response;
  }
)

  this.packageId=this.route.snapshot.params['id'];
  this.route.queryParams.subscribe(params =>
  {
    this.basePrice = Number(params['price']) || 0;
    this.booking.price = this.basePrice; // Set initial price
  });
  
}


// Function to update price based on number of members
updatePrice() {
  const members = Number(this.booking.totalMembers) || 1;
  const children = Number(this.booking.childrens) || 0;
  // Example pricing logic: children are charged at half price
  this.booking.price = this.basePrice * members + (this.basePrice * 0.5 * children);
}


submitBooking()
{
  this.packagebookingservice.addBooking(this.booking,this.userId,this.packageId).subscribe(
    (response:any)=>{
      if(response!=null){
        alert('Booking Successfull Do payment')
        this.router.navigate(['/paymenturl'], { queryParams: { amount: this.booking.price , userId: this.userId, bookingId: response.bookingId, roomId:this.roomId } });
      }
    });
  
}

}
