import { Component, OnInit } from '@angular/core';
import { RoomserviceService } from '../../../services/roomservice.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-updateroom',
  standalone: false,
  templateUrl: './updateroom.component.html',
  styleUrl: './updateroom.component.css'
})
export class UpdateroomComponent implements OnInit {
room:any;
roomId!:number;

constructor(private roomservice:RoomserviceService,private route:ActivatedRoute,private router:Router){}

ngOnInit(): void {
  this.roomId=this.route.snapshot.params['rId'];
    this.roomservice.getRoomById(this.roomId).subscribe(
      (response:any)=>{
        this.room=response;
      });
}

onSubmit(){
  this.roomservice.updateRoom(this.roomId,this.room).subscribe(()=>{
    alert('Room Updated Sucessfully');
    this.router.navigate(['/viewroomurl']);
  });
}
}