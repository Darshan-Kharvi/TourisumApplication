import { Component, OnInit } from '@angular/core';
import { PackagebookingService } from '../../../services/packagebooking.service';
import { ActivatedRoute, Router } from '@angular/router';
import { PackageBooking } from '../../../model/pacakagebooking';

@Component({
  selector: 'app-viewpackagebookings',
  standalone: false,
  templateUrl: './viewpackagebookings.component.html',
  styleUrl: './viewpackagebookings.component.css'
})
export class ViewpackagebookingsComponent implements OnInit {
packageBookingList:any;
packageBooking=new PackageBooking();
a:any;
constructor(private packagebookingservice:PackagebookingService,private route:ActivatedRoute,private router:Router){}

ngOnInit(): void {
  this.packagebookingservice.getAllBookings().subscribe(
    (response:any)=>{
      this.packageBookingList=response;
    });
}

deletePackageBooking(pacakgeBookingId:any)
{
  this.a = confirm('ARE YOU SURE TO DELETE THIS PRODUCT');
  if (this.a == true){
    console.log(pacakgeBookingId);
    this.packagebookingservice.deleteBookings(pacakgeBookingId).subscribe(
      (response:any)=>{
        this.packageBookingList=response;
        console.log(response);
      });
      alert('BOOKING IS DELETED');
  }else{
    alert('YOU DECIDED NOT TO DELETE BOOKING');
  }
}

updatePackageBooking(pacakgeBookingId:any)
{
  
}

}
