import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewroombookingsComponent } from './viewroombookings.component';

describe('ViewroombookingsComponent', () => {
  let component: ViewroombookingsComponent;
  let fixture: ComponentFixture<ViewroombookingsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ViewroombookingsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewroombookingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
