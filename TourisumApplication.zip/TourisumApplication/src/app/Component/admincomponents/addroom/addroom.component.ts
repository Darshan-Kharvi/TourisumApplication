import { Component } from '@angular/core';
import { Room } from '../../../model/room';
import { RoomserviceService } from '../../../services/roomservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-addroom',
  standalone: false,
  templateUrl: './addroom.component.html',
  styleUrl: './addroom.component.css'
})
export class AddroomComponent {
room=new Room();
constructor(private roomservice:RoomserviceService,private route:Router){}

addRoom(){
  console.log(this.room);
  this.roomservice.addRoom(this.room).subscribe(
    (response:any)=>{
      if(Response!=null)
        {
        // console.log(this.destination)
        alert("room adedd sucessfully");
        this.route.navigate(['/adminhomeurl']);
        }else
        alert("failed");
    });
}
}
