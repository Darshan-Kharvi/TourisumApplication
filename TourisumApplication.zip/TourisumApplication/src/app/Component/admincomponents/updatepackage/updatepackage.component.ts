import { Component, OnInit } from '@angular/core';
import { PackageserviceService } from '../../../services/packageservice.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-updatepackage',
  standalone: false,
  templateUrl: './updatepackage.component.html',
  styleUrl: './updatepackage.component.css'
})
export class UpdatepackageComponent implements OnInit {
packages:any;
packageId:any;

constructor(private packageservice:PackageserviceService,private route:ActivatedRoute,private router:Router){}
ngOnInit(): void {
  this.packageId=this.route.snapshot.params['packageId'];

  this.packageservice.getPacakgeById(this.packageId).subscribe(
    (response:any)=>{
      this.packages=response;
    });
}

onSubmit(){
  this.packageservice.updatePackage(this.packageId,this.packages).subscribe(
    ()=>{
      alert('Package Updated Successfully');
      this.router.navigate(['/viewpackageurl']);
    });
}
}
