import { Component, OnInit } from '@angular/core';
import { Tours } from '../../../model/tours';
import { TourserviceService } from '../../../services/tourservice.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-viewtours',
  standalone: false,
  templateUrl: './viewtours.component.html',
  styleUrl: './viewtours.component.css'
})
export class ViewtoursComponent implements OnInit {
  tourList:Tours[]=[]
  tour=new Tours();
  a: boolean = false;

  constructor(private toursservice:TourserviceService,private route:ActivatedRoute,private router:Router){}

  ngOnInit(): void {
   this.toursservice.getAllTours().subscribe(
    (Response: any) =>{
      this.tourList=Response;
    });
  }

  deleteTour(tourId:any){
    this.a = confirm('ARE YOU SURE TO DELETE THIS PRODUCT');
    if (this.a == true){
      console.log(tourId)
      this.toursservice.deleteTours(tourId).subscribe(
        (Response: any) => {
          this.tourList = Response;
          console.log(Response);
       });
       alert('TOUR IS DELETED');
    }else{
      alert('YOU DECIDED NOT TO DELETE TOUR');
    }
  }
  updateTour(tourId:any)
  {
    this.router.navigate(['/updatetoururl',tourId]);
  }

}
