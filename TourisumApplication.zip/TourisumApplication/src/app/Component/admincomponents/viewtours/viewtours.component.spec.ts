import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewtoursComponent } from './viewtours.component';

describe('ViewtoursComponent', () => {
  let component: ViewtoursComponent;
  let fixture: ComponentFixture<ViewtoursComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ViewtoursComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewtoursComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
