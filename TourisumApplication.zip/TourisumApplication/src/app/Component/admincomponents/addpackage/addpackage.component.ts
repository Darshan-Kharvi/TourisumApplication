import { Component } from '@angular/core';
import { Package } from '../../../model/package';
import { PackageserviceService } from '../../../services/packageservice.service';

@Component({
  selector: 'app-addpackage',
  standalone: false,
  templateUrl: './addpackage.component.html',
  styleUrl: './addpackage.component.css'
})
export class AddpackageComponent {
packages=new Package()

constructor(private packageservice:PackageserviceService){}

addPackage(){
  console.log(this.packages);
  this.packageservice.addPackage(this.packages).subscribe(
    (response:any)=>{
      if(Response!=null)
        {
        alert("Package adedd sucessfully");
        }else
        alert("failed");
    }
  )
}
}
