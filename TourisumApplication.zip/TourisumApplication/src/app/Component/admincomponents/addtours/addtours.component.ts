import { Component } from '@angular/core';
import { TourserviceService } from '../../../services/tourservice.service';
import { Tours } from '../../../model/tours';

@Component({
  selector: 'app-addtours',
  standalone: false,
  templateUrl: './addtours.component.html',
  styleUrl: './addtours.component.css'
})
export class AddtoursComponent {

  tour =new Tours();
  constructor(private tourservice:TourserviceService){}

  addTour(){
    console.log(this.tour);
    this.tourservice.addTours(this.tour).subscribe(
      (Response:any)=>
        {
          if(Response!=null)
          {
          // console.log(this.destination)
          alert("Tour adedd sucessfully");
          }else
          alert("failed");
        }
    );
  }

}
