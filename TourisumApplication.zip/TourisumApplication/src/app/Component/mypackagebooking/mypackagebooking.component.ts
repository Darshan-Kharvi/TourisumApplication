import { Component, OnInit } from '@angular/core';
import { PackagebookingService } from '../../services/packagebooking.service';
import { PackageBooking } from '../../model/pacakagebooking';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-mypackagebooking',
  standalone: false,
  templateUrl: './mypackagebooking.component.html',
  styleUrl: './mypackagebooking.component.css'
})
export class MypackagebookingComponent implements OnInit  {
packagebookingId:any;
packageBookings:PackageBooking[] = [];
userId: any;

constructor(private packagebookingservice:PackagebookingService,private route:ActivatedRoute,private router:Router){}

ngOnInit(): void {

  this.userId=sessionStorage.getItem('userId');
  console.log(this.userId);

  this.packagebookingId=this.route.snapshot.params['id'];
  console.log(this.userId);
  this.packagebookingservice.getPackageBookingById(this.userId).subscribe(
    (response:any)=>{
      console.log( response);
      this.packageBookings=response;
    });

}

}
