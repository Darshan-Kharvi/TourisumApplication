import { Component } from '@angular/core';
import { User } from '../../model/user';
import { UserService } from '../../services/user.service';
import { ActivatedRoute, Router } from '@angular/router';


@Component({
  selector: 'app-login',
  standalone: false,
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
 user = new User();
 isUserLoginFlag:boolean=false;
 userId:any;
   constructor(private userService: UserService,private route:ActivatedRoute,private router:Router){}
   loginUser(){

    const email = this.user.accountEmail?.trim();
    const password = this.user.password?.trim();

    if (!email || !password) {
      alert("Username or Password cannot be empty");
      return;
    }


    console.log(this.user.accountEmail);
    console.log(this.user.password);
    this.userService.loginUser(this.user).subscribe(
      (Response:any)=>
      {

        if (!Response) 
          {
          alert("USERNAME OR PASSWORD IS INCORRECT") 
          }else{
          alert("Login sucessfully");
          this.userId=Response.userId;
          this.isUserLoginFlag=this.userService.isUserLogin(this.userId);
          this.router.navigate(['homeurl']);
        }
       // else alert("Login failed!!");
      }
    );
   }
   
  /* createacc() {
    console.log(this.createacc)
    this.router.navigate(['signupurl']);
  }
*/
}
