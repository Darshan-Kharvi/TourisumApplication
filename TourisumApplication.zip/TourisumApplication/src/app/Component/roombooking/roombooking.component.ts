import { Component, OnInit } from '@angular/core';
import { RoomBooking } from '../../model/roombooking';
import { UserService } from '../../services/user.service';
import { ActivatedRoute, Router } from '@angular/router';
import { RoombookingService } from '../../services/roombooking.service';

@Component({
  selector: 'app-roombooking',
  standalone: false,
  templateUrl: './roombooking.component.html',
  styleUrl: './roombooking.component.css'
})
export class RoombookingComponent implements OnInit {
  booking1=new RoomBooking();
  roomId:any;
  roomType:any;
  basePrice: number = 0;
  totalPrice: number = 0;
  totalMembers: number = 1;
  //user: User | null = null;
  user:any;
  userId:any;

  constructor(private userService:UserService,private myroombookingservice:RoombookingService,private route:ActivatedRoute,private router:Router){}

  ngOnInit(): void {
    this.userId=sessionStorage.getItem('userId');
this.userService.getUserById(this.userId).subscribe(
  (Response:any)=>
  {
    this.user=Response;
  });

  
  this.roomId=this.route.snapshot.params['id'];
  this.route.queryParams.subscribe(params =>
  { 
    this.roomType=params['type'];
    this.basePrice = Number(params['price']) || 0;
    this.booking1.price = this.basePrice; // Set initial price
    this.booking1.roomType = this.roomType;
  });
  
  }

  
// Function to update price based on number of members
updatePrice() {
  const members = Number(this.booking1.totalMembers) || 1;
  const children = Number(this.booking1.childrens) || 0;
  // Example pricing logic: children are charged at half price
  this.booking1.price = this.basePrice * members + (this.basePrice * 0.5 * children);
}

submitBooking()
{
  this.myroombookingservice.addRoomBooking(this.booking1,this.userId,this.roomId).subscribe(
    (response:any)=>{
      if(response!=null){
        alert('Booking Successfull Do payment')
        this.router.navigate(['/paymenturl'] ,{queryParams :{amount:this.booking1.price ,userId: this.userId, bookingId: response.bookingId, roomId:this.roomId,roomPrice:this.booking1.price}});
      }
    });
}

}
