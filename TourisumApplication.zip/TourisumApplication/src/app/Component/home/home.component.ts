import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-home',
  standalone: false,
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent implements OnInit {
 // isUserLoginFlag:boolean=false;
  user:any;
  constructor(private userService: UserService){}
  userId:any;
  ngOnInit(): void {
this.userId=sessionStorage.getItem('userId');
this.userService.getUserById(this.userId).subscribe(
  (Response:any)=>
  {
    this.user=Response;
  }
)
  }


}
