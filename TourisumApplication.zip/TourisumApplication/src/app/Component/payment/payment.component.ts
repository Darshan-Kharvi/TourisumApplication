import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { paymentService } from '../../services/payment.service';
import { UserService } from '../../services/user.service';
import { Payment } from '../../model/payment';

@Component({
  selector: 'app-payment',
  standalone: false,
  templateUrl: './payment.component.html',
  styleUrl: './payment.component.css'
})
export class paymentComponent implements OnInit {
  //amount: number = 0;
  payment = new Payment();
  bookingId:any;
  user:any;
  userId:any;
  roomId:number=0;
  roomPrice:any;
  myGroup:any;
  
constructor(private paymentservice:paymentService,private route:ActivatedRoute,private userService:UserService){}


ngOnInit(): void {


  this.userId=sessionStorage.getItem('userId');
 this.userService.getUserById(this.userId).subscribe(
  (Response:any)=>
  {
    this.user=Response;
  }
  )


    this.route.queryParams.subscribe(params => {
    this.payment.paymentAmount = params['amount'] ? parseFloat(params['amount']) : 0;

    this.bookingId = params['bookingId']; //  Extract bookingId
    console.log('Extracted bookingId:', this.bookingId);  // Debugging log
    this.roomId=params['roomId'];
    console.log('Extracted roomId:', this.roomId);
    this.roomPrice=params['roomPrice'];
    console.log(this.roomPrice)
  });
}

submitPayment()
{

  console.log('Submitting payment:', this.payment);
  console.log('UserId:', this.userId, 'BookingId:', this.bookingId);


  this.paymentservice.addpayment(this.payment,this.userId,this.bookingId,this.roomId,this.roomPrice).subscribe(
    (response:any)=>{
      if(response!=null){
        alert('Payment sucessfull')
      }
    });

}
}
