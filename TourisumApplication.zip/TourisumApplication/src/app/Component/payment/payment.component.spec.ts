import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PackagepaymentComponent } from './payment.component';

describe('PackagepaymentComponent', () => {
  let component: PackagepaymentComponent;
  let fixture: ComponentFixture<PackagepaymentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PackagepaymentComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PackagepaymentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
