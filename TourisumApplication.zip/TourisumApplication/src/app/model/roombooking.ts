export class RoomBooking{
    bookingId:number|null;
    checkinDate: Date;
    checkoutDate:Date;
    totalMembers: string;
    childrens: string;
    status: string;
    price: number;
    roomType:string;
    rooms:string;

    constructor(){
        this.bookingId=null;
        this.checkinDate=new Date();
        this.checkoutDate=new Date();
        this.totalMembers=" ";
        this.childrens=" ";
        this.status=" ";
        this.price=0;
        this.roomType=" ";
        this.rooms=" ";

    }

}