export class Package{
    packageId:number|null;
    packageName:string;
    packageDescription:string;
    packagetype:string;
    image:string;
    packageprice:number;
    duration:string;
    cab:boolean;
    breakfast:boolean;
    sightvisit:boolean;
    room:boolean;
    campfire:boolean;
    meals:boolean;
    availableSeats:string;

    constructor(){
        this.packageId = null;
        this.packageName = " ";
        this.packageDescription =" ";
        this.packagetype = " ";
        this.image = " ";
        this.packageprice = 0;
        this.duration = " ";
        this.cab = false;
        this.breakfast = false;
        this.sightvisit = false;
        this.room = false;
        this.campfire = false;
        this.meals=false;
        this.availableSeats = " ";
    }
}