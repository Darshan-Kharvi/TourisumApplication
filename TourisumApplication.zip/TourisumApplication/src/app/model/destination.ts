export class Destination{
    destinationId:number|null;
    destinationName:string;
    location:string;
    description:string;
    image:string;

    constructor(){
    this.destinationId=null;
    this.destinationName=" ";
    this.location=" ";
    this.description=" ";
    this.image=" ";

    }
}