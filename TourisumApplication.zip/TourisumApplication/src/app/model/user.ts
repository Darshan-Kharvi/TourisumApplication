export class User
{
    userId:number|null;
    firstName:string;
    lastName:string;
    accountEmail:string;
    phoneNo:string;
    address:string;
    password:string;

    constructor()
    {
    this.userId=null;
    this.firstName="";
    this.lastName="";
    this.accountEmail="";
    this.phoneNo="";
    this.address="";
    this.password="";
    }
}