export class Room{
    roomId:number|null;
    roomName:string;
    location:string;
    description:string;
    image:string;
    price:number;
    roomtype:string;
    duration:string;
    meal:boolean;
    breakfast:boolean;
    campfire:boolean;


    constructor(){
    this.roomId=null;
    this.roomName=" ";
    this.location=" ";
    this.description=" ";
    this.image=" ";
    this.price=0;
    this.roomtype=" ";
    this.duration=" ";
    this.meal=false;
    this.breakfast=false;
    this.campfire=false;
    }
}